import socket
import ssl

HOST = "<host>"  
PORT = <port>  
k = 1  # Insert the correct modulus length

def send_test(test: bytes) -> bytes:
    # Create an SSL context
    context = ssl.create_default_context()

    # Establish a secure connection 
    with socket.create_connection((HOST, PORT)) as sock:
        with context.wrap_socket(sock, server_hostname=HOST) as ssl_sock:
            ssl_sock.sendall(test)

            # Receive the response (up to 64 bytes)
            response = ssl_sock.recv(64)

    return response

if __name__ == "__main__":
    # Example message:
    test = b"\x00" * k
    response = send_test(test)
    print("Oracle response:", response)
