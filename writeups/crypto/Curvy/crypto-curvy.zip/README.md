# Curvy challenge

This challenge is an easy introduction to elliptic curve cryptography.

The scripts are meant to be run with [SageMath](https://www.sagemath.org/) which can be installed locally, ran through one of their prebuilt docker images, or even [ran online](https://sagecell.sagemath.org/) with limitations to both run time and processor usage. Note that these servers are not part of EPT CTF at all, and attacks on these websites is out of scope.

Each challenge will produce a part of the flag. In order to solve the entire challenge, concatenate the flag parts like this:

`<part1><part2><part3>`
