from hashlib import sha256

def custom_password_hash(salt: bytes, data: bytes) -> int:
    h = sha256()
    for _ in range(2025):
        h.update(h.digest() + salt + b"eptctf" + data)
    return int(h.hexdigest(), 16)

P = 0x00df92df3b0b9006c0a8b1961229bc23b14f08a0065b8a0c85941f4a7543cffdfc26909f841bd1d62dae6a5ff72e88d942d7279529170b95f56611b9c247c6b49bb70c05f69a9289ec10c6f78dd0dd4ddec58bbd937881acd3633e47e86ad5f6bacb5b18fc08c1d8e32a5200efd98c37694e68aebe3c73f349a7fe4b76e8dfd4af
SRP_LEN = 128
k = 3
g = 2
DEMO_VERIFIER = 0x3e137ca7f34abd81baf668650594181e9f47f5496684adcc5c4551e44ee01b06ca4d985c97d40058b74057822e313bdcba2fb90692b8244aebb88b48c5d659c28f9c10b5017a41175da265084523af7112fc161fb563649882ea64d982a0f22a461cc57f090d636a1afad8815a94d3b46f4e885f347a697ec613c313af196bb7

class AuthError(Exception):
    pass