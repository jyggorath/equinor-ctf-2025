from pwn import remote, process
from hashlib import sha256
from Crypto.Util.number import long_to_bytes, bytes_to_long
from Crypto.Util.Padding import unpad
from Crypto.Cipher import AES
from common import *
import secrets

HOST, PORT = "hostname.here", 1337
LOCAL_TESTING = True  # Change this to test on remote

class Client():
    def __init__(self):
        if LOCAL_TESTING:
            self.socket = process(["python3", "server.py"])
        else:
            self.socket = remote(HOST, PORT, ssl=True)
        self.key = None

    def recv(self):
        res = self.socket.recvlineS()
        if res.startswith("!"): # Error message
            print(f"Received error: {res[1:]}")
            raise AuthError
        elif res.startswith("?"): # Encrypted message
            if not self.key:
                print("Cannot decrypt message without a key")
            else:
                data = bytes.fromhex(res[1:])
                try:
                    decrypted = unpad(AES.new(self.key, AES.MODE_CBC, data[:16]).decrypt(data[16:]), AES.block_size)
                    return decrypted.decode()
                except ValueError:
                    return ""
        else:
            print("DEBUG", res.strip())
            return res.strip()

    # Automatically solves the Proof-of-Work from the server
    def handle_pow(self):
        _, POW_enabled, POW_prefix, POW_difficulty = self.recv().split(":")
        POW_difficulty = int(POW_difficulty)

        print(f"{POW_enabled=} {POW_prefix=} {POW_difficulty=}")
        if int(POW_enabled):
            counter = 0
            while True:
                if (bytes_to_long(sha256((POW_prefix + str(counter)).encode()).digest()) >> (256 - POW_difficulty)) == 0:
                    self.socket.sendline(str(counter).encode())
                    return
                elif counter > 100_000_000:
                    print("Giving up on solving POW. Better luck next time")
                    exit()
                counter += 1


    # Attempts to log in with the given username and password
    # Even if the password is wrong, you should learn nothing, because this is ZK ;-)
    def authenticate(self, username, password):
        # Stage 1 - send username, get params
        self.socket.sendline(username.encode())
        salt = bytes.fromhex(self.recv())

        # Stage 2 - exchange public params
        a = secrets.randbits(1024)
        A = pow(g, a, P)
        self.socket.sendline(str(A).encode())

        B, u = map(int, self.recv().split(","))

        # Stage 3 - verify
        x = custom_password_hash(salt, password.encode())
        S = pow(B - k*pow(g, x, P), a + u*x, P)
        K = sha256(long_to_bytes(S, SRP_LEN)).digest()
        self.key = K

        # Build and send M1
        verify = sha256()
        verify.update(long_to_bytes(A, SRP_LEN))
        verify.update(long_to_bytes(B, SRP_LEN))
        verify.update(long_to_bytes(S, SRP_LEN))
        local_M = verify.digest()
        self.socket.sendline(local_M.hex().encode())

        print(f"User message: {self.recv()}")

        # Get M2 from server and verify it
        remote_M2 = self.recv()
        M2 = sha256()
        M2.update(long_to_bytes(A, SRP_LEN))
        M2.update(local_M)
        M2.update(long_to_bytes(S, SRP_LEN))
        M2 = M2.hexdigest()

        if remote_M2 != M2:
            print("Password mismatch")
            raise AuthError

        # If all went well, retrieve and display the user message!
        print(f"User message: {self.recv()}")
        self.socket.close()

if __name__ == "__main__":
    try:
        cli = Client()
        cli.handle_pow()
        cli.authenticate("demo", "demo")
    except AuthError as err:
        print(err)