import secrets, os, pickle
from hashlib import sha256
from Crypto.Util.number import long_to_bytes, bytes_to_long
from Crypto.Util.Padding import pad
from Crypto.Cipher import AES
from common import *

# Checks if the first bits of sha256(prefix + input) starts with zeros
def do_pow():
    POW_prefix = secrets.token_hex(16)
    print(f"POW:{POW_enabled:d}:{POW_prefix}:{POW_difficulty}")
    if POW_enabled and (bytes_to_long(sha256((POW_prefix + (ans := input())).encode()).digest()) >> (256 - POW_difficulty)) != 0:
        print("!POW failed")
        exit()


def print_encrypted_message(K, data):
    cipher = AES.new(K, AES.MODE_CBC)
    msg = (cipher.IV + cipher.encrypt(pad(data.encode(), AES.block_size)))
    print("?" + msg.hex())


def initialize_parameters():
    global admin_verifier, admin_salt, attempts

    if not os.path.exists("adminpw.txt"):
        admin_salt = secrets.token_hex(16)
        admin_password = admin_salt + str(secrets.randbelow(500_000))

        with open("adminpw.txt", "w") as fd:
            fd.write(admin_password + ':' + admin_salt)

    if not os.path.exists("attempts.pck"):
        attempts = {"admin" : 2, "demo" : 100}
    else:
        attempts = pickle.load(open("attempts.pck","rb"))

    admin_password, admin_salt = open("adminpw.txt","rb").read().split(b":")
    admin_verifier = pow(g, custom_password_hash(admin_salt, admin_password), P)

# Subtract an attempt when failing
def failure():
    attempts[username] = max(0, attempts[username] - 1)

    with open("attempts.pck","wb") as fd:
        pickle.dump(attempts, fd)

    exit()

FLAG = os.getenv("FLAG", "EPT{flag_for_testing}")

# POW paramaters. Disable this when testing locally. The server has it enabled to deter brute force attacks. Brute force against the server is not required.
POW_enabled = True
POW_difficulty = 22 # Number of required leading zero bits
do_pow()

# Get and/or generate the admin password, salt and login attempts
initialize_parameters()

# Password for demo is 'demo'
USERS = { "admin": (FLAG, admin_verifier, admin_salt),
          "demo": ('Hello! This is a demo message.', DEMO_VERIFIER, b'saltysalt')
        }


# Verify that username exists
username = input()
if username not in USERS:
    print("!User not found")
    exit()

if attempts[username] <= 0:
    # This means you have to start the challenge container over again
    print(f"!User account has been locked after too many failed attempts.")
    exit()

message, verifier, salt = USERS[username]

# Send the user salt
print(salt.hex())

# Receive and verify public params
A = int(input())
if not 1 < A < P:
    print("!Bad parameters")
    exit()

b = secrets.randbits(1024)
B = (k * verifier + pow(g, b, P)) % P
u = secrets.randbits(1024)
S = pow( A * pow(verifier, u, P), b, P)
K = sha256(long_to_bytes(S, SRP_LEN)).digest()

# Send blinded verifier and the randomness used
print(f"{B},{u}")

print_encrypted_message(K, f"Welcome '{username}'! Here is your custom message:")
# Check if the user knows the password
M1 = bytes.fromhex(input())

local_M1 = sha256()
local_M1.update(long_to_bytes(A, SRP_LEN))
local_M1.update(long_to_bytes(B, SRP_LEN))
local_M1.update(long_to_bytes(S, SRP_LEN))
local_M1 = local_M1.digest()

if local_M1 != M1:
    print("!Password mismatch")
    failure()

local_M2 = sha256()
local_M2.update(long_to_bytes(A, SRP_LEN))
local_M2.update(local_M1)
local_M2.update(long_to_bytes(S, SRP_LEN))
local_M2 = local_M2.hexdigest()

print(local_M2)

print_encrypted_message(K, message)