#!/usr/bin/env python3
import base64

def rot(char, shift):
    return chr(33 + (ord(char) - 33 + shift) % 94)

def rot_string(text, shift):
    """
    Apply ROT transformation to an entire string.
    """
    return ''.join(rot(char, shift) for char in text)

def encrypt(plaintext, key):
    """
    Encrypt plaintext using the key with ROT47 and base64 encoding.
    For each character in the key, apply ROT47 to the entire text, then base64 encode.
    """
    if not key:
        raise ValueError("Key cannot be empty")
    
    # Start with the plaintext
    ciphertext = plaintext
    
    # For each character in the key
    for key_char in key:
        # Apply ROT to the entire current ciphertext
        ciphertext = rot_string(ciphertext, shift=int(ord(key_char)))
        
        # Base64 encode the result
        encoded_bytes = base64.b64encode(ciphertext.encode('ascii'))
        ciphertext = encoded_bytes.decode('ascii')
    
    return ciphertext

def main(plaintext, key):
    def is_printable_ascii(text):
        return all(33 <= ord(char) <= 126 for char in text)
    
    if not is_printable_ascii(plaintext):
        print("Error: Plaintext must contain only printable ASCII characters (! to ~)!")
        return
    
    if not is_printable_ascii(key):
        print("Error: Key must contain only printable ASCII characters (! to ~)!")
        return
    
    if not plaintext:
        print("Error: Plaintext cannot be empty!")
        return
    
    if not key:
        print("Error: Key cannot be empty!")
        return
    
    return encrypt(plaintext, key)

if __name__ == "__main__":
    plaintext = input("Enter plaintext: ")
    key = input("Enter key: ")
    cipher = main(plaintext, key)
    with open("cipher.txt", "w") as f:
        f.write(cipher)