"""
Library to encode msgpack structures. Only supports dicts with strings for now!
"""

from io import BytesIO
from hashlib import sha256
import hmac, os

class SecureMsgPack(object):
    def __init__(self, key = None):
        if key == None:
            key = os.urandom(32)
        self.key = key

    def to_message_pack(self, data):
        msg = b""
        msg += bytes([0x80 + len(data)])

        for key,value in data.items():
            msg += bytes([0xA0 + len(key.strip().lower().encode("utf8"))])
            msg += key.strip().encode("utf8")
            msg += bytes([0xA0 + len(value.strip().lower().encode("utf8"))])
            msg += value.strip().encode("utf8")

        h = hmac.new(self.key, msg, sha256).digest()
        return msg + h

    def from_message_pack(self, data):
        h1, data = data[-32:], data[:-32]
        h2 = hmac.new(self.key, data, sha256).digest()
        if h1 != h2:
            raise ValueError("HMAC verification failed. Message has been tampered with")
        
        msg = {}
        data = BytesIO(data)
        num_elements = data.read(1)[0] - 0x80
        for _ in range(num_elements):
            strlen = data.read(1)[0] - 0xA0
            key = data.read(strlen)
            strlen = data.read(1)[0] - 0xA0
            value = data.read(strlen)
            msg[key.decode("utf8")] = value.decode("utf8", "ignore")

        return msg

"""
Run a small test suite to see that it works flawlessly
"""
if __name__ == "__main__":
    import random, os
    from string import printable
    
    alphabet = printable.rstrip() + "ÆØÅæøå"  # i18n
    
    def randomstring(k):
        return ''.join(random.choice(alphabet) for _ in range(k))

    TRIALS = 10_000

    for _ in range(TRIALS):
        SMP = SecureMsgPack()
        L = random.randint(1, 32)
        json_before = {randomstring(random.randint(1, 32)) : randomstring(random.randint(1, 32)) }
        msgpack = SMP.to_message_pack(json_before)
        json_after = SMP.from_message_pack(msgpack)
        assert json_before == json_after