import os
from flask import Flask, request, render_template, make_response, url_for
from dataclasses import dataclass
from msgpack import SecureMsgPack
from random import choice

FLAG = os.getenv("FLAG", "EPT{flag_for_testing}")

SMP = SecureMsgPack()

app = Flask(__name__)

intros = [
    "Ahh, {}! I can see that",
    "Ohh yes, {}, you're famous because",
    "{}? Interesting name... My crystal ball tells me that",
    "I see you are still trying, {}. Remember that",
]

secrets = [
    "you still think 'phishing' involves actual fish.",
    "you tried to brute force your own Wi-Fi password... and locked yourself out.",
    "you once saved your passwords in a file called 'totally_not_passwords.txt'.",
    "you once asked if a firewall needed actual bricks.",
    "you believe 'social engineering' means being good at parties.",
    "you copied 'sudo rm -rf /' into Google just to see what it does.",
    "you accidentally encrypted your homework and can't decrypt it.",
    "you think hashing is something you do with potatoes.",
    "you got phished by an email claiming to offer free antivirus... from 'DefinitelyNotAScam.ru'.",
    "you installed Kali Linux, but only use it to play Minesweeper.",
    "you ran live ransomware at an in-person CTF.",
    "you secretly want the flag...",
    "YOU NEED TO TRY HARDED!!!",
]


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/secret", methods=["POST"])
def secret():    
    username = request.form.get("username")

    if len(username.encode("utf-8")) > 32:
        return "Don't you think that username is a bit too long?"

    token = SMP.to_message_pack({"username":username, "type":"USER"})
    
    res = make_response()
    res.set_cookie("userdata", value=token.hex())
    res.headers['location'] = url_for('info')

    return res, 302

@app.route("/info", methods=["GET"])
def info():
    token = request.cookies.get('userdata')
    try:
        userdata = SMP.from_message_pack(bytes.fromhex(token))
        intro = choice(intros).format(userdata["username"])
        secret = choice(secrets) if userdata["type"] == "USER" else FLAG

    except (ValueError, KeyError):
        return "Something went wrong during decoding. Did you mess with the token?"
    
    return f"{intro} {secret}"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False) # Set this to True for easy debugging locally
