from flask import Flask, jsonify, render_template, request, flash
import os
import boto3
from botocore.exceptions import ClientError

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Needed for flash messages


def validate_email(email: str) -> bool:
    if not email:
        return False

    email_lower = email.lower().strip()

    valid_domains = ["ept.gg", "eptc.tf"]

    # Check if email ends with any of the valid domains
    for domain in valid_domains:
        if email_lower.endswith("@" + domain):
            return True

    return False


def send_email(email: str):
    if os.environ.get("ENVIRONMENT") != "prod":
        app.logger.info(f"Mocking email send to {email}.")
        app.logger.info(f"Skipping email sending in non-production environment")
        return True

    flag = open("flag.txt").read().strip()

    # Get AWS credentials from environment variables
    aws_access_key_id = os.environ.get("AWS_ACCESS_KEY_ID")
    aws_secret_access_key = os.environ.get("AWS_SECRET_ACCESS_KEY")

    if not aws_access_key_id or not aws_secret_access_key:
        app.logger.error("AWS credentials not found in environment variables")
        return False

    try:
        ses_client = boto3.client(
            "ses",
            "eu-west-1",
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )

        subject = "Ship it!"
        text_body = f"Here is your flag: {flag}"
        response = ses_client.send_email(
            Source="EPT Flag Ship <noreply@mail.ept.gg>",
            Destination={"ToAddresses": [email]},
            Message={
                "Subject": {"Data": subject, "Charset": "UTF-8"},
                "Body": {
                    "Text": {"Data": text_body, "Charset": "UTF-8"},
                },
            },
        )

        app.logger.info(
            f"Verification email sent to {email}. Message ID: {response['MessageId']}"
        )
        return True
    except ClientError as e:
        app.logger.error(f"Failed to send email to {email}.")
        return False
    except Exception as e:
        app.logger.error(f"Failed to send email: {e}")
        return False


@app.route("/", methods=["GET", "POST"])
def home():
    # Handle GET requests
    if request.method == "GET":
        return render_template("index.html")

    # Handle POST requests
    if request.method == "POST":
        email = request.form.get("email")

        if validate_email(email):
            if send_email(email):
                app.logger.info(f"Email sent to: {email}")
                flash("An email has been sent to your address.", "success")
            else:
                flash("Failed to send email. Please try again later.", "danger")
                app.logger.error(f"Failed to send email to: {email}")
        else:
            flash(
                "Invalid email domain. Only @ept.gg and @eptc.tf are allowed.", "danger"
            )

        return render_template("index.html")


@app.route("/health")
def health():
    return jsonify({"status": "healthy", "service": "onereg"})


def main():
    """Main entry point for running the application."""
    app.run(host="0.0.0.0", port=5000, debug=True)


if __name__ == "__main__":
    main()
