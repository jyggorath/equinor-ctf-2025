"""Spin-For-Flag FastAPI application package."""
