from __future__ import annotations

import random
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Set

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, field_validator
from uuid import uuid4

from ctf_config import DAILY_COOLDOWN_SECS, FLAG, WIN_PROBABILITY

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"

app = FastAPI(title="Spin-For-Flag")
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

FINGERPRINT_TTL_SECS = 15

VISITOR_ID_PATTERN = re.compile(r'^[a-zA-Z0-9]{20}$')

surveys: Dict[str, Dict[str, Any]] = {}
visitor_spins: Dict[str, datetime] = {}
fingerprints: Dict[str, Dict[str, Any]] = {}
win_counter = 0  # Tracks wins, resets after 3


def split_flag_into_parts(flag: str) -> list[str]:
    """Split flag into 3 roughly equal parts"""
    if flag.startswith("EPT{") and flag.endswith("}"):
        core = flag[4:-1]
        prefix = "EPT{"
        suffix = "}"
    else:
        core = flag
        prefix = ""
        suffix = ""
    
    # Split into 3 parts
    part_len = len(core) // 3
    part1 = prefix + core[:part_len]
    part2 = core[part_len:part_len*2]
    part3 = core[part_len*2:] + suffix
    
    return [part1, part2, part3]


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def raise_fraud(survey_uuid: str, reason: str) -> None:
    raise HTTPException(
        status_code=403,
        detail={
            "isBlocked": True,
            "message": reason,
            "errorCode": 1403,
            "requestId": uuid4().hex,
        },
    )


def is_valid_visitor_id(visitor_id: str) -> bool:
    """Validate that visitorId matches expected format"""
    if not visitor_id or not isinstance(visitor_id, str):
        return False
    return bool(VISITOR_ID_PATTERN.match(visitor_id))


def prune_fingerprints(current: datetime) -> None:
    cutoff = current - timedelta(seconds=FINGERPRINT_TTL_SECS)
    expired = [key for key, entry in fingerprints.items() if entry["timestamp"] < cutoff]
    for key in expired:
        fingerprints.pop(key, None)


def store_fingerprint_entry(
    request_id: str,
    *,
    visitor_id: str,
    survey_uuid: str,
    timestamp: datetime,
    confidence: float,
    version: str,
) -> None:
    fingerprints[request_id] = {
        "visitorId": visitor_id,
        "survey_uuid": survey_uuid,
        "timestamp": timestamp,
        "confidence": confidence,
        "version": version,
    }


class ConfidencePayload(BaseModel):
    score: float
    revision: Optional[str] = ""

    @field_validator("score")
    @classmethod
    def score_range(cls, value: float) -> float:
        if not 0.0 <= value <= 1.0:
            raise ValueError("score must be between 0.0 and 1.0")
        if value < 0.5:
            raise ValueError("confidence score suspiciously low")
        return value


class FingerprintPayload(BaseModel):
    survey_uuid: str
    visitorId: str
    requestId: str
    confidence: ConfidencePayload
    version: Optional[str] = ""
    device: Optional[str] = ""
    browserName: Optional[str] = ""
    os: Optional[str] = ""

    model_config = ConfigDict(str_strip_whitespace=True, extra="allow")


class SpinRequest(BaseModel):
    survey_uuid: str
    visitorId: str
    requestId: str

    model_config = ConfigDict(str_strip_whitespace=True)


@app.get("/", response_class=FileResponse)
async def landing_page() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/survey/{survey_uuid}", response_class=FileResponse)
async def survey_page(survey_uuid: str) -> FileResponse:
    surveys.setdefault(survey_uuid, {"spun": False, "visitorId": None, "timestamp": None})
    return FileResponse(STATIC_DIR / "survey.html")

@app.get("/spin/{survey_uuid}", response_class=FileResponse)
async def spin_page(survey_uuid: str) -> FileResponse:
    surveys.setdefault(survey_uuid, {"spun": False, "visitorId": None, "timestamp": None})
    return FileResponse(STATIC_DIR / "spin.html")


class SurveySubmission(BaseModel):
    name: Optional[str] = ""
    email: Optional[str] = ""
    feedback: Optional[str] = ""
    color: Optional[str] = ""
    confidence: Optional[str] = ""
    motto: Optional[str] = ""

    class Config:
        extra = "allow"


@app.post("/api/survey")
async def submit_survey(submission: SurveySubmission) -> Dict[str, str]:
    """Accept survey submissions (data is not stored, just acknowledged)"""
    return {"status": "success", "message": "Survey submitted successfully"}


@app.post("/api/survey/start")
async def start_survey() -> Dict[str, str]:
    survey_uuid = str(uuid4())
    surveys.setdefault(survey_uuid, {"spun": False, "visitorId": None, "timestamp": None})
    return {"survey_uuid": survey_uuid}


@app.post("/api/fingerprint")
async def capture_fingerprint(payload: FingerprintPayload, request: Request):
    now = now_utc()
    survey_uuid = payload.survey_uuid
    request_id = payload.requestId
    visitor_id = payload.visitorId

    if not survey_uuid:
        raise_fraud(payload.survey_uuid, "Invalid request")
    if not request_id:
        raise_fraud(payload.survey_uuid, "Invalid request")
    if not visitor_id:
        raise_fraud(payload.survey_uuid, "Invalid visitor identifier")
    
    if not is_valid_visitor_id(visitor_id):
        raise_fraud(payload.survey_uuid, "Invalid visitor identifier format")

    last_spin = visitor_spins.get(visitor_id)
    if last_spin and (now - last_spin) < timedelta(seconds=DAILY_COOLDOWN_SECS):
        raise_fraud(payload.survey_uuid, "You've already participated. Please come back tomorrow!")

    surveys.setdefault(survey_uuid, {"spun": False, "visitorId": None, "timestamp": None})

    store_fingerprint_entry(
        request_id,
        visitor_id=visitor_id,
        survey_uuid=survey_uuid,
        timestamp=now,
        confidence=payload.confidence.score,
        version=payload.version or "",
    )

    prune_fingerprints(now)

    return {"isBlocked": False, "message": "Fingerprint accepted"}


@app.post("/api/spin")
async def spin_wheel(spin: SpinRequest, request: Request):
    now = now_utc()
    survey_uuid = spin.survey_uuid
    visitor_id = spin.visitorId
    request_id = spin.requestId

    if not survey_uuid or not visitor_id or not request_id:
        return JSONResponse({"message": "Invalid request data."}, status_code=400)

    if not is_valid_visitor_id(visitor_id):
        return JSONResponse({"message": "Invalid visitor identifier format."}, status_code=400)

    fingerprint_entry = fingerprints.get(request_id)
    if not fingerprint_entry:
        return JSONResponse({"message": "Fingerprint verification failed. Please try again."}, status_code=400)

    if fingerprint_entry["visitorId"] != visitor_id:
        return JSONResponse({"message": "Fingerprint verification failed."}, status_code=400)
    
    if fingerprint_entry["survey_uuid"] != survey_uuid:
        return JSONResponse({"message": "Fingerprint verification failed."}, status_code=400)

    if (now - fingerprint_entry["timestamp"]).total_seconds() > FINGERPRINT_TTL_SECS:
        fingerprints.pop(request_id, None)
        return JSONResponse({"message": "Fingerprint expired. Please refresh and try again."}, status_code=400)

    survey = surveys.setdefault(survey_uuid, {"spun": False, "visitorId": None, "timestamp": None})
    
    if survey.get("spun"):
        return JSONResponse({"message": "This survey link has already been used."}, status_code=403)

    last_spin = visitor_spins.get(visitor_id)
    if last_spin and (now - last_spin) < timedelta(seconds=DAILY_COOLDOWN_SECS):
        return JSONResponse({"message": "You've already spun today. Come back tomorrow!"}, status_code=403)

    survey["spun"] = True
    survey["visitorId"] = visitor_id
    survey["timestamp"] = now
    fingerprints.pop(request_id, None)
    visitor_spins[visitor_id] = now

    won = random.random() < WIN_PROBABILITY
    
    if won:
        global win_counter
        flag_parts = split_flag_into_parts(FLAG)
        current_part = flag_parts[win_counter % 3]
        win_counter += 1
        
        part_number = ((win_counter - 1) % 3) + 1
        
        return {
            "result": "flag",
            "flag": current_part,
            "message": f"🎉 Congratulations! You won part {part_number}/3 of the flag!",
        }
    else:
        return {
            "result": "no_flag",
            "message": "Better luck next time! Thanks for spinning.",
        }

