(() => {
  "use strict";

  document.addEventListener("DOMContentLoaded", () => {
    const page = document.body.dataset.page;
    if (page === "landing") {
      initLandingPage();
    } else if (page === "survey") {
      initSurveyPage();
    }
  });

  function initLandingPage() {
    const button = document.getElementById("start-survey");
    if (!button) {
      return;
    }
    button.addEventListener("click", () => startSurvey(button));
  }

  function initSurveyPage() {
    const segments = window.location.pathname.split("/").filter(Boolean);
    const surveyUuid = segments[segments.length - 1];
    const form = document.getElementById("survey-form");
    const continueButton = document.getElementById("continue-button");

    if (!surveyUuid || !form || !continueButton) {
      return;
    }

    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      continueButton.disabled = true;
      continueButton.textContent = "Opening wheel...";
      setTimeout(() => {
        window.location.href = `/spin/${surveyUuid}`;
      }, 150);
    });
  }

  async function startSurvey(button) {
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = "Preparing survey...";
    try {
      const response = await fetch("/api/survey/start", { method: "POST" });
      if (!response.ok) {
        const error = new Error("Unable to create survey link.");
        error.status = response.status;
        throw error;
      }
      const body = await response.json();
      const surveyUuid = body && typeof body.survey_uuid === "string" ? body.survey_uuid : null;
      if (!surveyUuid) {
        throw new Error("Survey identifier missing from response.");
      }
      window.location.href = `/survey/${surveyUuid}`;
    } catch (err) {
      console.error("Failed to start survey", err);
      button.disabled = false;
      button.textContent = originalText;
      window.alert("Unable to start the survey right now. Please try again.");
    }
  }
})();
