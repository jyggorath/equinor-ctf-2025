(() => {
  "use strict";

  let agentPromise = null;
  const missingLibraryError = new Error("FingerprintJS library not available.");

  function randomId() {
    if (window.crypto && typeof window.crypto.getRandomValues === "function") {
      const bytes = new Uint32Array(4);
      window.crypto.getRandomValues(bytes);
      return Array.from(bytes, (value) => value.toString(16).padStart(8, "0")).join("");
    }
    return (
      Math.random().toString(16).slice(2) +
      Math.random().toString(16).slice(2) +
      Math.random().toString(16).slice(2)
    ).slice(0, 32);
  }

  function detectBrowser() {
    const ua = navigator.userAgent || "";
    if (ua.includes("Firefox")) return "Firefox";
    if (ua.includes("Edg/")) return "Edge";
    if (ua.includes("Chrome")) return "Chrome";
    if (ua.includes("Safari")) return "Safari";
    return "Unknown";
  }

  function detectOS() {
    const ua = navigator.userAgent || "";
    if (ua.includes("Win")) return "Windows";
    if (ua.includes("Mac")) return "macOS";
    if (ua.includes("Linux")) return "Linux";
    if (ua.includes("Android")) return "Android";
    if (ua.includes("iPhone") || ua.includes("iPad")) return "iOS";
    return "Unknown";
  }

  function detectDevice() {
    const ua = navigator.userAgent || "";
    if (/Tablet|iPad/i.test(ua)) return "tablet";
    if (/Mobile|Android|iPhone/i.test(ua)) return "mobile";
    return "desktop";
  }

  window.CTFFingerprint = {
    load() {
      if (agentPromise) {
        return agentPromise;
      }
      if (!window.FingerprintJS || typeof window.FingerprintJS.load !== "function") {
        return Promise.reject(missingLibraryError);
      }
      agentPromise = window.FingerprintJS.load()
        .then((fp) => ({
          async get(options = {}) {
            const surveyUuid = typeof options === "string" ? options : options?.surveyUuid;
            if (!surveyUuid) {
              throw new Error("Missing survey identifier for fingerprint generation.");
            }
            const result = await fp.get();
            const visitorId = typeof result?.visitorId === "string" ? result.visitorId.trim() : "";
            if (!visitorId) {
              throw new Error("Fingerprint agent could not determine a visitor id.");
            }
            const confidence =
              result &&
              result.confidence &&
              typeof result.confidence.score === "number"
                ? result.confidence
                : { score: 0 };
            return {
              visitorId,
              requestId: randomId(),
              version: result?.version || "fingerprintjs-3",
              confidence,
              device: detectDevice(),
              browserName: detectBrowser(),
              os: detectOS(),
            };
          },
        }))
        .catch((error) => {
          agentPromise = null;
          throw error;
        });
      return agentPromise;
    },
  };
})();
