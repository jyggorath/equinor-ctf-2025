import os

FLAG = os.getenv("FLAG", "CTF{REPLACE_ME}")
WIN_PROBABILITY = float(os.getenv("WIN_PROBABILITY", "0.05"))
DAILY_COOLDOWN_SECS = int(os.getenv("DAILY_COOLDOWN_SECS", str(24 * 60 * 60)))
