const navButtons = document.querySelectorAll(".nav-item[data-fragment]");
const tabSections = document.querySelectorAll("[data-tab]");
const chatForm = document.getElementById("chat-form");
const chatUrlInput = document.getElementById("chat-url");
const chatOutput = document.getElementById("chat-output");

function buildGotoUrl(fragment) {
  const target = `/static/index.html#${fragment}`;
  return `/goto?url=${encodeURIComponent(target)}`;
}

function activateTab(fragment) {
  tabSections.forEach((section) => {
    const isMatch = section.dataset.tab === fragment;
    section.hidden = !isMatch;
    section.classList.toggle("active", isMatch);
  });

  navButtons.forEach((button) => {
    const isMatch = button.dataset.fragment === fragment;
    button.classList.toggle("active", isMatch);
  });
}

function syncFromHash() {
  const fragment = window.location.hash.replace(/^#/, "") || "home";
  activateTab(fragment);
}

navButtons.forEach((button) => {
  button.addEventListener("click", (event) => {
    event.preventDefault();
    const fragment = button.dataset.fragment;
    window.location.href = buildGotoUrl(fragment);
  });
});

window.addEventListener("hashchange", syncFromHash, { passive: true });
window.addEventListener("DOMContentLoaded", () => {
  // Add loaded class to enable fade-in and prevent FOUC
  document.body.classList.add('loaded');
  syncFromHash();
}, { once: true });

function renderChatMessage(message, options = {}) {
  chatOutput.innerHTML = "";
  const wrapper = document.createElement("div");
  wrapper.className = "chat-message";

  if (options.statusCode !== undefined) {
    const meta = document.createElement("p");
    meta.className = "chat-meta";
    const finalUrl = options.finalUrl ? ` → ${options.finalUrl}` : "";
    meta.textContent = `Status: ${options.statusCode}${finalUrl}`;
    wrapper.appendChild(meta);
  }

  const body = document.createElement("pre");
  body.className = "chat-body";
  body.textContent = message;
  wrapper.appendChild(body);

  chatOutput.appendChild(wrapper);
}

if (chatForm) {
  chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const url = chatUrlInput.value.trim();
    if (!url) {
      return;
    }

    renderChatMessage("Jenny is loading…");

    try {
      const response = await fetch("/chatbot/check", {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url }),
      });

      const data = await response.json();
      if (!response.ok || !data.ok) {
        const errorMessage = data.error || `Unexpected error (${response.status})`;
        renderChatMessage(errorMessage);
        return;
      }

      renderChatMessage(data.preview || "No preview returned.", {
        statusCode: data.status_code ?? data.statusCode,
        finalUrl: data.final_url ?? data.finalUrl,
      });
    } catch (error) {
      renderChatMessage(`Request failed: ${error}`);
    }
  });
}
