"""FastAPI application for the Jenny chatbot challenge."""
from __future__ import annotations

import asyncio
import os
from typing import Any, Optional
from urllib.parse import urlparse

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.middleware.base import RequestResponseEndpoint
from starlette.responses import Response

from playwright.async_api import Browser, Error, Playwright, async_playwright


FLAG_DEFAULT = "FLAG{not_the_flag_you're_looking_for}"
STAFF_COOKIE_VALUE = os.getenv("STAFF_COOKIE_VALUE", "staff_cookie_value")
CORP_ALLOWED_SUFFIX = os.getenv("CORP_ALLOWED_SUFFIX", "ofcors.local.host")

app = FastAPI(title="Jenny, the Good Old Chatbot")
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=".*",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")

_playwright: Optional[Playwright] = None
_browser: Optional[Browser] = None
_browser_lock = asyncio.Lock()


@app.middleware("http")
async def reinforce_staff_cookie(request: Request, call_next: RequestResponseEndpoint) -> Response:
    response = await call_next(request)
    session_cookie = request.cookies.get("session")
    if session_cookie == STAFF_COOKIE_VALUE:
        # Keep the staff session cookie active for Jenny.
        response.set_cookie(
            key="session",
            value=STAFF_COOKIE_VALUE,
            httponly=True,
            secure=True,
            samesite="none",
        )
    return response


@app.on_event("startup")
async def startup() -> None:
    global _playwright, _browser
    _playwright = await async_playwright().start()
    _browser = await _playwright.chromium.launch(headless=True)


@app.on_event("shutdown")
async def shutdown() -> None:
    global _playwright, _browser
    if _browser:
        await _browser.close()
    if _playwright:
        await _playwright.stop()


class ChatbotRequest(BaseModel):
    url: str


def _host_is_corporate(candidate: Optional[str], request_host: Optional[str]) -> bool:
    if not candidate:
        return False

    candidate = candidate.lower()
    suffix_env = (CORP_ALLOWED_SUFFIX or "").strip().lower()

    if request_host and candidate == request_host.lower():
        return True

    if not suffix_env:
        return False

    normalized = suffix_env.lstrip('.')
    if normalized and candidate == normalized:
        return True

    patterns = set()
    if normalized:
        patterns.add(normalized)
        patterns.add(f".{normalized}")
        patterns.add(f"-{normalized}")

    for pattern in patterns:
        if candidate.endswith(pattern):
            return True

    return False


@app.get("/", response_class=FileResponse)
async def read_root() -> Any:
    index_path = os.path.join(os.path.dirname(__file__), "static", "index.html")
    return FileResponse(index_path)


@app.get("/goto")
async def redirect(url: str) -> RedirectResponse:
    return RedirectResponse(url)


@app.get("/flag")
async def get_flag(request: Request) -> JSONResponse:
    if request.cookies.get("session") == STAFF_COOKIE_VALUE:
        flag_value = os.getenv("FLAG", FLAG_DEFAULT)
        return JSONResponse({"flag": flag_value})
    return JSONResponse(status_code=403, content={"error": "forbidden"})


async def _ensure_browser() -> Browser:
    async with _browser_lock:
        if _browser is None:
            raise RuntimeError("Browser not initialised")
        return _browser


async def _fetch_with_jenny(target_url: str) -> tuple[str, int, str]:
    browser = await _ensure_browser()
    context = await browser.new_context()
    page = await context.new_page()

    parsed = urlparse(target_url)
    cookie_domain = parsed.hostname or ""

    if cookie_domain:
        await context.add_cookies(
            [
                {
                    "name": "session",
                    "value": STAFF_COOKIE_VALUE,
                    "domain": cookie_domain,
                    "path": "/",
                    "httpOnly": True,
                    "secure": True,
                    "sameSite": "None",
                }
            ]
        )

    navigation_response: Optional[Any] = None
    try:
        navigation_response = await page.goto(target_url, wait_until="networkidle")
        final_url = page.url
        status_code = navigation_response.status if navigation_response else 0

        preview_text = ""
        try:
            preview_text = await page.inner_text("body")
        except Error:
            try:
                preview_text = await page.content()
            except Error:
                preview_text = ""

        preview_text = (preview_text or "").strip()
        if len(preview_text) > 400:
            preview_text = preview_text[:400]

        if urlparse(final_url).path.startswith("/flag"):
            # Hide restricted pages from the chat preview while navigation continues.
            preview_text = 'Jenny: "I cannot disclose that here."'

        return final_url, status_code, preview_text
    finally:
        await context.close()


@app.post("/chatbot/check")
async def chatbot_check(payload: ChatbotRequest, request: Request) -> JSONResponse:
    submitted_url = payload.url.strip()
    try:
        parsed = urlparse(submitted_url)
    except ValueError as exc:
        return JSONResponse(status_code=400, content={"ok": False, "error": "invalid url", "details": str(exc)})

    if parsed.scheme not in {"http", "https"}:
        return JSONResponse(status_code=400, content={"ok": False, "error": "invalid scheme"})

    if not _host_is_corporate(parsed.hostname, request.url.hostname):
        return JSONResponse(status_code=400, content={"ok": False, "error": "host not allowed"})

    try:
        final_url, status_code, preview_text = await _fetch_with_jenny(submitted_url)
        return JSONResponse(
            {
                "ok": True,
                "input_url": submitted_url,
                "final_url": final_url,
                "status_code": status_code,
                "preview": preview_text,
            }
        )
    except Exception as exc:  # noqa: BLE001
        # Surface a generic failure message when navigation fails.
        return JSONResponse(status_code=500, content={"ok": False, "error": "fetch failed", "details": str(exc)})
