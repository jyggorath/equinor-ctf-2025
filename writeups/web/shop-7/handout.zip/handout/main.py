import json
import os
import secrets

from flask import Flask, redirect, render_template, request

app = Flask(__name__)


class Item:
    id: str
    name: str
    description: str
    value: str
    price: int


class Customer:
    id: str
    name: str
    password: str
    __token: str
    __cash: int = 137

    def __init__(self):
        self.id = secrets.token_hex(16)
        self.__token = secrets.token_hex(16)

    def add_cash(self, amount: int):
        self.__cash += amount

    def remove_cash(self, amount: int):
        self.__cash -= amount

    def get_cash(self):
        return self.__cash

    def get_token(self):
        return self.__token


class Transaction:
    id: str
    customer: Customer
    item: Item


class TransactionManager:
    __transactions: list[Transaction] = []

    def add_transaction(self, transaction: Transaction):
        self.__transactions.append(transaction)

    def get_transactions(self):
        return list(self.__transactions)

    def get_transaction(self, id: str):
        return next((transaction for transaction in self.__transactions if transaction.id == id), None)

    def get_transaction_by_customer(self, customer: Customer):
        return list(filter(lambda transaction: transaction.customer == customer, self.__transactions))


class ShopManager:
    __customers: list[Customer] = []
    __items: list[Item] = []
    __transactions: TransactionManager = TransactionManager()

    def add_customer(self, customer: Customer):
        self.__customers.append(customer)

    def add_item(self, item: Item):
        self.__items.append(item)

    def get_customers(self):
        return list(self.__customers)

    def get_items(self):
        return list(self.__items)

    def get_transactions(self):
        return self.__transactions.get_transactions()

    def add_transaction(self, transaction: Transaction):
        self.__transactions.add_transaction(transaction)

    def get_transaction(self, id: str):
        return self.__transactions.get_transaction(id)

    def get_transaction_by_customer(self, customer: Customer):
        return self.__transactions.get_transaction_by_customer(customer)


shop_manager = ShopManager()

with open("items.json", "r") as f:
    data = f.read().replace("FLAG", os.environ.get("FLAG", "FLAG"))
    items = json.loads(data)
    for item in items:
        store_item = Item()
        for key, value in item.items():
            setattr(store_item, key, value)
        shop_manager.add_item(store_item)


@app.route("/", methods=["GET"])
def index():
    token = request.cookies.get("token")
    customer = next((customer for customer in shop_manager.get_customers() if customer.get_token() == token), None)
    return render_template("index.html", items=shop_manager.get_items(), customer=customer, transactions=shop_manager.get_transaction_by_customer(customer))


@app.route("/register", methods=["POST"])
def register():
    data = request.json
    customer = Customer()
    for key, value in data.items():
        setattr(customer, key, value)
    shop_manager.add_customer(customer)
    response = redirect("/")
    response.set_cookie("token", customer.get_token())
    return response


@app.route("/buy", methods=["POST"])
def buy():
    token = request.cookies.get("token")
    customer = next((customer for customer in shop_manager.get_customers() if customer.get_token() == token), None)
    if not customer:
        return redirect("/")
    data = request.json
    item = next((item for item in shop_manager.get_items() if item.id == data["item_id"]), None)
    if not item:
        return redirect("/")
    if customer.get_cash() < item.price:
        return redirect("/")
    customer.remove_cash(item.price)
    transaction = Transaction()
    transaction.customer = customer
    transaction.item = item
    shop_manager.add_transaction(transaction)
    return redirect("/")


if __name__ == "__main__":
    app.run(port=1337, host="0.0.0.0", threaded=False, debug=False)
