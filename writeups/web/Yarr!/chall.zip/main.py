#!/usr/bin/env python3

import os
import time

from aiohttp import ClientSession, web

with open("index.html", "r") as f:
    index_html = f.read()


def filter_bad_characters(text):
    for forbidden_char in ";<=>?@":
        text = text.replace(forbidden_char, ".")
    return text

async def index(_):
    return web.Response(text=index_html, content_type="text/html")


async def fetch_game(request):
    game = filter_bad_characters(request.match_info["game"])

    async with ClientSession() as session:
        try:
            async with session.get(f"http://{game}.games.ept:80/") as response:
                text = await response.text()
                return web.Response(text=text, content_type="text/html")
        except Exception as e:
            return web.Response(text=f"Error fetching game '{game}': {str(e)}", status=500)


app = web.Application()
app.router.add_get("/", index)
app.router.add_get("/{game:[0-z]+}/", fetch_game)
web.run_app(app, port=8080)
