#!/bin/bash

# Start nginx on port 80
nginx -c /app/nginx.conf -g "daemon off;" &

# Wait a moment for servers to start
sleep 2

# Execute main.py as the main process
exec python /app/main.py
