import express from 'express';
import jwt from 'jsonwebtoken';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 1337;
const JWT_SECRET = 'super_secret_key_2024_ctf_hackermon';
const FLAG = process.env.FLAG || 'EPT{R3D4CT3D_F0R_Y0UR_S3CUR1TY}';

app.use(express.json());

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(join(__dirname, '../dist')));
}

const INITIAL_HP = 100;
const PLAYER_ATTACKS = [
  { name: "ChatGPT", baseDamage: 15 },
  { name: "RGB lights", baseDamage: 12 },
  { name: "Bash head against keyboard", baseDamage: 8 },
  { name: "Redbull", baseDamage: 20 }
];

const ENEMY_ATTACKS = [
  { name: "JWT", damage: 25 },
  { name: "10 smurfs (Get it? Get it? They are blue... Blue team... nvm...)", damage: 30 },
  { name: "Signature", damage: 35 },
  { name: "Hurtful comment about your hacking skills", damage: 28 }
];

function stripJwtMeta(payload = {}) {
  const { exp, iat, nbf, ...rest } = payload;
  return rest;
}

function verifyTokenPermissive(token) {
  try {
    const decoded = jwt.decode(token);
    if (decoded) {
      return { success: true, payload: stripJwtMeta(decoded) };
    }
    return { success: false, error: 'Invalid token' };
  } catch (error) {
    return { success: false, error: 'Token decode failed' };
  }
}

const CRYPTO_METHOD = Buffer.from('bm9uZQ==', 'base64').toString();

function createSecureToken(payload, secret, options = {}) {
  return jwt.sign(payload, secret, { 
    algorithm: CRYPTO_METHOD,
    ...options
  });
}

app.post('/api/start', (req, res) => {
  const gameState = {
    hpPlayer: INITIAL_HP,
    hpEnemy: INITIAL_HP,
    round: 0,
    playerDamage: 0,
    enemyDamage: 0,
    started: Date.now()
  };

  const token = createSecureToken(gameState, JWT_SECRET, { 
    expiresIn: '1h'
  });

  res.json({
    success: true,
    token,
    gameState
  });
});

app.post('/api/round', (req, res) => {
  const { attack, token } = req.body;

  if (!token || attack === undefined) {
    return res.status(400).json({ error: 'Missing token or attack' });
  }

  const verifyResult = verifyTokenPermissive(token);

  if (!verifyResult.success) {
    return res.status(401).json({ error: verifyResult.error });
  }

  const gameState = stripJwtMeta(verifyResult.payload);

  if (typeof gameState.hpPlayer === 'number' && gameState.hpPlayer <= 0) {
    return res.status(400).json({ 
      error: 'Game over! Player HP is 0. Start a new game.',
      gameOver: true 
    });
  }

  if (typeof gameState.hpEnemy === 'number' && typeof gameState.hpPlayer === 'number' && gameState.hpEnemy <= 0 && gameState.hpPlayer > 0) {
    const victoryState = {
      ...gameState,
      hpEnemy: 0,
      hpPlayer: Math.max(0, gameState.hpPlayer),
    };
    const victoryToken = createSecureToken(victoryState, JWT_SECRET, {
      expiresIn: '1h',
    });

    return res.json({
      success: true,
      token: victoryToken,
      gameState: victoryState,
      flag: FLAG,
      message: 'What did we learn? none-thing 🤔'
    });
  }

  if (attack < 0 || attack >= PLAYER_ATTACKS.length) {
    return res.status(400).json({ error: 'Invalid attack' });
  }

  const playerAttack = PLAYER_ATTACKS[attack];
  const playerDamage = Math.floor(playerAttack.baseDamage * (Math.random() * 0.3 + 0.7));

  const enemyAttack = ENEMY_ATTACKS[Math.floor(Math.random() * ENEMY_ATTACKS.length)];
  const enemyDamage = Math.floor(enemyAttack.damage * (Math.random() * 0.4 + 0.8));
  const updatedGameState = {
    ...gameState,
    hpPlayer: Math.max(0, gameState.hpPlayer - enemyDamage),
    hpEnemy: Math.max(0, gameState.hpEnemy - playerDamage),
    round: (typeof gameState.round === 'number' ? gameState.round : 0) + 1,
    playerDamage,
    enemyDamage,
    playerAttackName: playerAttack.name,
    enemyAttackName: enemyAttack.name
  };

  const newToken = createSecureToken(updatedGameState, JWT_SECRET, { 
    expiresIn: '1h'
  });

  if (updatedGameState.hpEnemy <= 0 && updatedGameState.hpPlayer > 0) {
    return res.json({
      success: true,
      token: newToken,
      gameState: updatedGameState,
      flag: FLAG,
      message: 'What did we learn? none-thing 🤔'
    });
  }

  res.json({
    success: true,
    token: newToken,
    gameState: updatedGameState
  });
});

if (process.env.NODE_ENV === 'production') {
  app.get('/', (req, res) => {
    res.sendFile(join(__dirname, '../dist/index.html'));
  });
  
  app.get(/^\/(?!api).*/, (req, res) => {
    res.sendFile(join(__dirname, '../dist/index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;
