# Hackermon

## Running Locally

### Option 1: Development Mode
```bash
npm install
npm run dev
```
- Frontend: `http://localhost:5173`
- Backend API: `http://localhost:5000`

### Option 2: Docker (Recommended)
```bash
docker-compose up --build
```
- Complete application: `http://localhost:1337`

