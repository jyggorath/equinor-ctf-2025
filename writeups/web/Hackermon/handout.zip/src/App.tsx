import React, { useState, useEffect, useCallback, useRef } from 'react';
import soundtrackAsset from './synthwave-80s-retro-background-music-400483.mp3';

// Use public folder images for better loading performance
const hackerSprite = '/images/hacker.png';
const defenderSprite = '/images/defender.png';

interface GameState {
  gameStarted: boolean;
  gameToken: string | null;
  playerHp: number;
  enemyHp: number;
  maxPlayerHp: number;
  maxEnemyHp: number;
  selectedAttack: number;
  gameMessage: string;
  lastDamage: { player: number; enemy: number } | null;
  roundNumber: number;
  gameWon: boolean;
  flag: string | null;
}

const PLAYER_ATTACKS = [
  "ChatGPT",
  "RGB lights", 
  "Bash head against keyboard",
  "Redbull"
];

function App() {
  const [gameState, setGameState] = useState<GameState>({
    gameStarted: false,
    gameToken: null,
    playerHp: 100,
    enemyHp: 100,
    maxPlayerHp: 100,
    maxEnemyHp: 100,
    selectedAttack: 0,
    gameMessage: "A wild SUIT appeared!",
    lastDamage: null,
    roundNumber: 0,
    gameWon: false,
    flag: null
  });

  const [playerAnim, setPlayerAnim] = useState<'idle' | 'attack' | 'hit'>('idle');
  const [enemyAnim, setEnemyAnim] = useState<'idle' | 'attack' | 'hit'>('idle');
  const [musicEnabled, setMusicEnabled] = useState(true);
  const [musicActive, setMusicActive] = useState(false);
  const animationTimeouts = useRef<number[]>([]);
  const soundtrackRef = useRef<HTMLAudioElement | null>(null);

  const clearAnimationTimeouts = useCallback(() => {
    animationTimeouts.current.forEach((id) => window.clearTimeout(id));
    animationTimeouts.current = [];
  }, []);

  const queueAnimationTimeout = useCallback((callback: () => void, delay: number) => {
    const id = window.setTimeout(() => {
      animationTimeouts.current = animationTimeouts.current.filter((storedId) => storedId !== id);
      callback();
    }, delay);
    animationTimeouts.current.push(id);
  }, []);

  useEffect(() => {
    return () => {
      clearAnimationTimeouts();
    };
  }, [clearAnimationTimeouts]);

  useEffect(() => {
    const audio = new Audio(soundtrackAsset);
    audio.loop = true;
    audio.volume = 0.35;
    soundtrackRef.current = audio;

    const handlePlay = () => setMusicActive(true);
    const handlePause = () => setMusicActive(false);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);

    return () => {
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.pause();
      soundtrackRef.current = null;
    };
  }, []);

  const requestMusicPlay = useCallback(() => {
    const audio = soundtrackRef.current;
    if (!audio) return;
    if (!audio.paused) {
      setMusicActive(true);
      return;
    }
    const result = audio.play();
    if (result && typeof result.then === 'function') {
      result
        .then(() => setMusicActive(true))
        .catch(() => setMusicActive(false));
    } else {
      setMusicActive(true);
    }
  }, []);

  const pauseMusic = useCallback(() => {
    const audio = soundtrackRef.current;
    if (!audio) return;
    if (!audio.paused) {
      audio.pause();
    }
    setMusicActive(false);
  }, []);

  useEffect(() => {
    const audio = soundtrackRef.current;
    if (!audio) return;
    if (musicEnabled) {
      requestMusicPlay();
    } else {
      pauseMusic();
    }
  }, [musicEnabled, pauseMusic, requestMusicPlay]);

  useEffect(() => {
    return () => {
      pauseMusic();
    };
  }, [pauseMusic]);

  const handleToggleMusic = () => {
    setMusicEnabled((prev) => !prev);
  };

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!gameState.gameStarted || gameState.gameWon) return;
      
      switch(e.key) {
        case 'ArrowUp':
          e.preventDefault();
          if (gameState.selectedAttack >= 2) {
            setGameState(prev => ({ ...prev, selectedAttack: prev.selectedAttack - 2 }));
          }
          break;
        case 'ArrowDown':
          e.preventDefault();
          if (gameState.selectedAttack <= 1) {
            setGameState(prev => ({ ...prev, selectedAttack: prev.selectedAttack + 2 }));
          }
          break;
        case 'ArrowLeft':
          e.preventDefault();
          if (gameState.selectedAttack % 2 === 1) {
            setGameState(prev => ({ ...prev, selectedAttack: prev.selectedAttack - 1 }));
          }
          break;
        case 'ArrowRight':
          e.preventDefault();
          if (gameState.selectedAttack % 2 === 0 && gameState.selectedAttack + 1 < PLAYER_ATTACKS.length) {
            setGameState(prev => ({ ...prev, selectedAttack: prev.selectedAttack + 1 }));
          }
          break;
        case 'Enter':
        case ' ':
          e.preventDefault();
          if (gameState.gameStarted && !gameState.gameWon && gameState.playerHp > 0) {
            handleAttack();
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gameState.gameStarted, gameState.selectedAttack, gameState.gameWon, gameState.playerHp]);

  const startGame = async () => {
    if (musicEnabled) {
      requestMusicPlay();
    }
    try {
      const response = await fetch('/api/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();

      clearAnimationTimeouts();
      setPlayerAnim('idle');
      setEnemyAnim('idle');

      setGameState(prev => ({
        ...prev,
        gameStarted: true,
        gameToken: data.token,
        playerHp: data.gameState.hpPlayer,
        enemyHp: data.gameState.hpEnemy,
        maxPlayerHp: data.gameState.hpPlayer,
        maxEnemyHp: data.gameState.hpEnemy,
        gameMessage: "Choose your attack!"
      }));
    } catch (error) {
      console.error('Failed to start game:', error);
    }
  };

  const handleAttack = async () => {
    if (!gameState.gameToken || gameState.gameWon || gameState.playerHp <= 0) return;

    if (musicEnabled) {
      requestMusicPlay();
    }

    clearAnimationTimeouts();
    setEnemyAnim('idle');
    setPlayerAnim('attack');
    queueAnimationTimeout(() => setPlayerAnim('idle'), 320);

    try {
      const response = await fetch('/api/round', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attack: gameState.selectedAttack,
          token: gameState.gameToken
        })
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Failed to process attack:', data);
        clearAnimationTimeouts();
        setPlayerAnim('idle');
        setEnemyAnim('idle');
        return;
      }

      const nextState = data.gameState ?? {};

      setGameState(prev => {
        const nextToken = data.token ?? prev.gameToken;
        const resolvedMessage = data.message
          ?? (nextState.playerAttackName && nextState.enemyAttackName
            ? `You used ${nextState.playerAttackName}! Enemy used ${nextState.enemyAttackName}!`
            : prev.gameMessage);

        const nextGameWon = Boolean(data.flag) || prev.gameWon;
        return {
          ...prev,
          gameToken: nextToken,
          playerHp: typeof nextState.hpPlayer === 'number' ? nextState.hpPlayer : prev.playerHp,
          enemyHp:
            nextGameWon
              ? 0
              : (typeof nextState.hpEnemy === 'number' ? nextState.hpEnemy : prev.enemyHp),
          lastDamage:
            typeof nextState.playerDamage === 'number' || typeof nextState.enemyDamage === 'number'
              ? {
                  player: typeof nextState.playerDamage === 'number' ? nextState.playerDamage : (prev.lastDamage?.player ?? 0),
                  enemy: typeof nextState.enemyDamage === 'number' ? nextState.enemyDamage : (prev.lastDamage?.enemy ?? 0)
                }
              : prev.lastDamage,
          roundNumber: typeof nextState.round === 'number' ? nextState.round : prev.roundNumber,
          gameMessage: resolvedMessage,
          gameWon: nextGameWon,
          flag: data.flag ?? prev.flag
        };
      });

      if (typeof nextState.playerDamage === 'number' && nextState.playerDamage > 0) {
        queueAnimationTimeout(() => setEnemyAnim('hit'), 140);
        queueAnimationTimeout(() => setEnemyAnim('idle'), 480);
      }

      if (typeof nextState.enemyDamage === 'number' && nextState.enemyDamage > 0) {
        queueAnimationTimeout(() => setEnemyAnim('attack'), 520);
        queueAnimationTimeout(() => setEnemyAnim('idle'), 880);
        queueAnimationTimeout(() => setPlayerAnim('hit'), 540);
        queueAnimationTimeout(() => setPlayerAnim('idle'), 900);
      }

      if (typeof nextState.hpPlayer === 'number' && nextState.hpPlayer <= 0) {
        setGameState(prev => ({ ...prev, gameMessage: "You were defeated! Try again..." }));
        queueAnimationTimeout(() => setPlayerAnim('hit'), 200);
        queueAnimationTimeout(() => setPlayerAnim('idle'), 600);
      }
    } catch (error) {
      console.error('Failed to process attack:', error);
      clearAnimationTimeouts();
      setPlayerAnim('idle');
      setEnemyAnim('idle');
    }
  };

  const handleAttackWithIndex = async (attackIndex: number) => {
    if (!gameState.gameToken || gameState.gameWon || gameState.playerHp <= 0) return;

    if (musicEnabled) {
      requestMusicPlay();
    }

    clearAnimationTimeouts();
    setEnemyAnim('idle');
    setPlayerAnim('attack');
    queueAnimationTimeout(() => setPlayerAnim('idle'), 320);

    try {
      const response = await fetch('/api/round', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attack: attackIndex,
          token: gameState.gameToken
        })
      });

      const data = await response.json();

      if (!response.ok) {
        console.error('Failed to process attack:', data);
        clearAnimationTimeouts();
        setPlayerAnim('idle');
        setEnemyAnim('idle');
        return;
      }

      const nextState = data.gameState ?? {};

      setGameState(prev => {
        const nextToken = data.token ?? prev.gameToken;
        const resolvedMessage = data.message
          ?? (nextState.playerAttackName && nextState.enemyAttackName
            ? `You used ${nextState.playerAttackName}! Enemy used ${nextState.enemyAttackName}!`
            : prev.gameMessage);

        const nextGameWon = Boolean(data.flag) || prev.gameWon;
        return {
          ...prev,
          gameToken: nextToken,
          playerHp: typeof nextState.hpPlayer === 'number' ? nextState.hpPlayer : prev.playerHp,
          enemyHp:
            nextGameWon
              ? 0
              : (typeof nextState.hpEnemy === 'number' ? nextState.hpEnemy : prev.enemyHp),
          lastDamage:
            typeof nextState.playerDamage === 'number' || typeof nextState.enemyDamage === 'number'
              ? {
                  player: typeof nextState.playerDamage === 'number' ? nextState.playerDamage : (prev.lastDamage?.player ?? 0),
                  enemy: typeof nextState.enemyDamage === 'number' ? nextState.enemyDamage : (prev.lastDamage?.enemy ?? 0)
                }
              : prev.lastDamage,
          roundNumber: typeof nextState.round === 'number' ? nextState.round : prev.roundNumber,
          gameMessage: resolvedMessage,
          gameWon: nextGameWon,
          flag: data.flag ?? prev.flag
        };
      });

      if (typeof nextState.playerDamage === 'number' && nextState.playerDamage > 0) {
        queueAnimationTimeout(() => setEnemyAnim('hit'), 140);
        queueAnimationTimeout(() => setEnemyAnim('idle'), 480);
      }

      if (typeof nextState.enemyDamage === 'number' && nextState.enemyDamage > 0) {
        queueAnimationTimeout(() => setEnemyAnim('attack'), 520);
        queueAnimationTimeout(() => setEnemyAnim('idle'), 880);
        queueAnimationTimeout(() => setPlayerAnim('hit'), 540);
        queueAnimationTimeout(() => setPlayerAnim('idle'), 900);
      }

      if (typeof nextState.hpPlayer === 'number' && nextState.hpPlayer <= 0) {
        setGameState(prev => ({ ...prev, gameMessage: "You were defeated! Try again..." }));
        queueAnimationTimeout(() => setPlayerAnim('hit'), 200);
        queueAnimationTimeout(() => setPlayerAnim('idle'), 600);
      }
    } catch (error) {
      console.error('Failed to process attack:', error);
      clearAnimationTimeouts();
      setPlayerAnim('idle');
      setEnemyAnim('idle');
    }
  };

  const handleAttackSelection = (index: number) => {
    if (!gameState.gameStarted || gameState.gameWon || gameState.playerHp <= 0) return;

    // Set the selected attack and immediately execute it
    setGameState(prev => ({ ...prev, selectedAttack: index }));
    handleAttackWithIndex(index);
  };

  const resetGame = async () => {
    clearAnimationTimeouts();
    setPlayerAnim('idle');
    setEnemyAnim('idle');

    // Reset to initial state first
    setGameState(prev => ({
      ...prev,
      gameWon: false,
      flag: null,
      selectedAttack: 0,
      lastDamage: null,
      gameMessage: "Starting new game..."
    }));

    // Start a new game directly
    try {
      const response = await fetch('/api/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      const data = await response.json();

      clearAnimationTimeouts();
      setPlayerAnim('idle');
      setEnemyAnim('idle');

      setGameState(prev => ({
        ...prev,
        gameStarted: true,
        gameToken: data.token,
        playerHp: data.gameState.hpPlayer,
        enemyHp: data.gameState.hpEnemy,
        maxPlayerHp: data.gameState.hpPlayer,
        maxEnemyHp: data.gameState.hpEnemy,
        roundNumber: data.gameState.round,
        gameMessage: "Choose your attack!",
        gameWon: false,
        flag: null,
        selectedAttack: 0,
        lastDamage: null
      }));
    } catch (error) {
      console.error('Failed to restart game:', error);
      // Fallback to showing start screen if API call fails
      clearAnimationTimeouts();
      setPlayerAnim('idle');
      setEnemyAnim('idle');
      setGameState({
        gameStarted: false,
        gameToken: null,
        playerHp: 100,
        enemyHp: 100,
        maxPlayerHp: 100,
        maxEnemyHp: 100,
        selectedAttack: 0,
        gameMessage: "A wild SUIT appeared!",
        lastDamage: null,
        roundNumber: 0,
        gameWon: false,
        flag: null
      });
    }
  };

  const enemySpriteClass = [
    'hackermon-sprite',
    'enemy',
    enemyAnim === 'attack' ? 'enemy-attack' : '',
    enemyAnim === 'hit' ? 'enemy-hit' : ''
  ]
    .filter(Boolean)
    .join(' ');

  const enemySpriteStyle: React.CSSProperties = {
    backgroundImage: `url(${defenderSprite})`,
  };

  const playerSpriteClass = [
    'hackermon-sprite',
    'player',
    playerAnim === 'attack' ? 'player-attack' : '',
    playerAnim === 'hit' ? 'player-hit' : ''
  ]
    .filter(Boolean)
    .join(' ');

  const playerSpriteStyle: React.CSSProperties = {
    backgroundImage: `url(${hackerSprite})`,
  };

  const enemyHpPercent = Math.max(
    0,
    Math.min(100, gameState.maxEnemyHp ? (gameState.enemyHp / gameState.maxEnemyHp) * 100 : 0)
  );
  const playerHpPercent = Math.max(
    0,
    Math.min(100, gameState.maxPlayerHp ? (gameState.playerHp / gameState.maxPlayerHp) * 100 : 0)
  );

  return (
    <div className="min-h-screen bg-black text-green-400 font-mono relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="h-full w-full bg-gradient-to-b from-transparent via-green-900/10 to-transparent bg-repeat-y animate-pulse"
          style={{ backgroundSize: '100% 4px' }}
        ></div>
      </div>

      <div className="relative z-10 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold mb-2 text-green-300" style={{ fontFamily: '"Press Start 2P", monospace' }}>
              HACKERMON
            </h1>
            <p className="text-sm text-green-600">Gotta exploit 'em all!</p>
            <div className="mt-3 flex justify-center">
              <button
                onClick={handleToggleMusic}
                className={`inline-flex items-center gap-2 rounded-full border-2 px-4 py-2 text-[10px] font-bold uppercase tracking-widest transition-colors ${
                  musicEnabled ? 'border-green-400 bg-green-500/10 text-green-100 hover:bg-green-500/20' : 'border-red-400 bg-red-500/10 text-red-100 hover:bg-red-500/20'
                }`}
              >
                <span role="img" aria-hidden="true">{musicEnabled && musicActive ? '🎵' : '🔇'}</span>
                {musicEnabled ? (musicActive ? 'Mute soundtrack' : 'Resume soundtrack') : 'Play soundtrack'}
              </button>
            </div>
          </div>

          {!gameState.gameStarted ? (
            <div className="text-center">
              <div className="bg-gray-900 border-4 border-green-400 p-8 rounded-lg mb-4">
                <p className="mb-4 text-lg">Welcome!</p>
                <p className="mb-6 text-sm">Can you defeat THE SUIT?</p>
                <button
                  onClick={startGame}
                  className="bg-green-600 hover:bg-green-700 text-black font-bold py-3 px-8 rounded border-2 border-green-400 transition-colors"
                  style={{ fontFamily: '"Press Start 2P", monospace' }}
                >
                  BEGIN
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-gray-900 border-4 border-green-400 rounded-2xl p-6 md:p-8 space-y-6 shadow-lg">
                <div className="relative h-80 md:h-96 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 border-4 border-green-500/40 rounded-2xl overflow-hidden">
                  <div className="absolute inset-x-0 top-1/2 h-px bg-green-500/8"></div>

                  <div className="absolute top-10 left-1/2 -translate-x-1/2 transform">
                    <div className={enemySpriteClass} style={enemySpriteStyle}></div>
                  </div>

                  <div className="absolute bottom-8 left-1/2 -translate-x-1/2 transform">
                    <div className={playerSpriteClass} style={playerSpriteStyle}></div>
                  </div>

                  <div className="absolute top-6 right-6 flex flex-col gap-1 rounded-md border border-red-300/40 bg-black/65 px-3 py-2 text-[9px] uppercase tracking-widest text-red-100 shadow-lg shadow-red-900/40">
                    <span className="text-right">THE SUIT</span>
                    <div className="h-2 w-40 overflow-hidden rounded-sm border border-red-300/40 bg-black/40">
                      <div className="h-full bg-red-400" style={{ width: `${enemyHpPercent}%` }}></div>
                    </div>
                    <span className="text-[8px] font-mono tracking-normal normal-case text-right">
                      {gameState.enemyHp}/{gameState.maxEnemyHp} HP
                    </span>
                  </div>

                  <div className="absolute bottom-6 left-6 flex flex-col gap-1 rounded-md border border-green-300/40 bg-black/65 px-3 py-2 text-[9px] uppercase tracking-widest text-green-100 shadow-lg shadow-emerald-900/40">
                    <span>HACKER</span>
                    <div className="h-2 w-40 overflow-hidden rounded-sm border border-green-300/40 bg-black/40">
                      <div className="h-full bg-green-400" style={{ width: `${playerHpPercent}%` }}></div>
                    </div>
                    <span className="text-[8px] font-mono tracking-normal normal-case">
                      {gameState.playerHp}/{gameState.maxPlayerHp} HP
                    </span>
                  </div>

                  <div className="absolute inset-0 pointer-events-none">
                    <div className="absolute top-28 left-1/2 -translate-x-1/2 w-40 h-12 rounded-full bg-green-500/14 blur-3xl"></div>
                    <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-44 h-14 rounded-full bg-blue-500/14 blur-3xl"></div>
                  </div>
                </div>

                <div className={`bg-gray-950/80 border-4 border-green-500/40 rounded-xl p-4 min-h-[96px] flex flex-col gap-2 ${gameState.gameWon ? 'items-center text-center' : ''}`}>
                  <p className="text-sm text-green-200 leading-relaxed">{gameState.gameMessage}</p>
                  {gameState.lastDamage && gameState.playerHp > 0 && !gameState.gameWon && (
                    <p className="text-xs text-yellow-300">
                      You dealt {gameState.lastDamage.player} damage • Defender dealt {gameState.lastDamage.enemy}
                    </p>
                  )}
                  {gameState.flag && (
                    <div className="mt-3 flex flex-col items-center gap-3">
                      <div className="text-lg font-bold text-green-300 tracking-widest uppercase">Flag Captured</div>
                      <div className="rounded-xl border border-green-400/60 bg-green-900/30 px-4 py-3 text-sm font-mono text-green-100 shadow-[0_0_25px_rgba(16,185,129,0.35)]">
                        {gameState.flag}
                      </div>
                    </div>
                  )}
                </div>

                <div className="bg-gray-950/90 border-4 border-green-500/60 rounded-xl p-4">
                  {!gameState.gameWon && gameState.playerHp > 0 ? (
                    <>
                      <p className="text-xs uppercase tracking-widest text-green-400 mb-3 text-center">
                        Select attack (↑ ↓ ← → + Enter)
                      </p>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        {PLAYER_ATTACKS.map((attack, index) => {
                          const isSelected = gameState.selectedAttack === index;
                          return (
                            <button
                              key={attack}
                              onClick={() => handleAttackSelection(index)}
                              className={`flex items-center gap-2 px-3 py-4 border-2 rounded-xl transition-all duration-200 text-left ${
                                isSelected
                                  ? 'bg-green-700/70 border-green-300 text-green-50 shadow-[0_0_15px_rgba(34,197,94,0.35)]'
                                  : 'bg-gray-800/80 border-gray-600 text-gray-300 hover:bg-gray-700/70'
                              }`}
                            >
                              <span className="text-green-300 w-4 text-center">{isSelected ? '>' : ''}</span>
                              <span className="flex-1 leading-tight">{attack}</span>
                              {isSelected && <span className="text-yellow-300">⚡</span>}
                            </button>
                          );
                        })}
                      </div>
                    </>
                  ) : (
                    <div className="text-center space-y-3">
                      <button
                        onClick={resetGame}
                        className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded border-2 border-blue-400 transition-colors"
                        style={{ fontFamily: '"Press Start 2P", monospace', fontSize: '10px' }}
                      >
                        PLAY AGAIN
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
