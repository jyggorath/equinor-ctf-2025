#!/bin/sh

# Choose config file based on environment
if [ "$ENV_MODE" = "localhost" ]; then
    echo "Starting nginx with localhost configuration (port included in redirects)"
    cp /etc/nginx/nginx.dev.conf /etc/nginx/nginx.conf
else
    echo "Starting nginx with remote configuration (port excluded from redirects)"
    # nginx.conf is already in place
fi

# Start nginx
nginx -g 'daemon off;'
