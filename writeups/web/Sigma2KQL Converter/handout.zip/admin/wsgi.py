from app import app
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from werkzeug.wrappers import Response

application = DispatcherMiddleware(Response('Not Found', status=404), {
    '/admin': app
})