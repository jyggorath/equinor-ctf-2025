import os, bcrypt, time, threading
import os, time, threading, secrets
from flask import Flask, render_template, render_template_string, request, redirect, session, url_for, flash, jsonify
from werkzeug.middleware.proxy_fix import ProxyFix
from models import db, User
from sqlalchemy.exc import OperationalError
from sqlalchemy import text
import psycopg2
import sys, logging
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
sys.stdout.reconfigure(line_buffering=True)

app = Flask(__name__)
admin_secret = os.getenv("ADMIN_SECRET")
if not admin_secret:
    raise RuntimeError("ADMIN_SECRET environment variable is required but not set. Refuse to start for security reasons.")

app_generated_key = secrets.token_hex(32)  # 32 bytes = 256 bits of entropy
app.secret_key = admin_secret + app_generated_key
app.config['APPLICATION_ROOT'] = '/admin'

# Configure for reverse proxy (nginx/load balancer)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1, x_prefix=1)

app.config['PREFERRED_URL_SCHEME'] = 'http'
app.config['SERVER_NAME'] = None

app.config["SQLALCHEMY_DATABASE_URI"] = (
    f"postgresql://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}/{os.getenv('DB_NAME')}"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Global flag to track database readiness
db_ready = threading.Event()

def check_db_connection():
    """Check if database connection is ready"""
    try:
        with app.app_context():
            with db.engine.connect() as connection:
                connection.execute(text("SELECT 1"))
        return True
    except (OperationalError, psycopg2.OperationalError, Exception):
        return False

def wait_for_db_background():
    """Background thread to wait for database"""
    app.logger.info("Admin service starting - checking database connection...")
    max_retries = 60
    initial_delay = 1
    max_delay = 10
    
    for attempt in range(max_retries):
        if check_db_connection():
            app.logger.info(f"Database is ready! Admin service fully operational (attempt {attempt + 1})")
            db_ready.set()
            return
        
        delay = min(initial_delay * (1.5 ** attempt), max_delay)
        app.logger.info(f"Database not ready (attempt {attempt + 1}/{max_retries}). Retrying in {delay:.1f}s")
        time.sleep(delay)
    
    app.logger.error("Database connection failed after all retries. Service will remain in starting state.")

# Start background database check
threading.Thread(target=wait_for_db_background, daemon=True).start()

@app.before_request
def check_service_ready():
    """Check if service is ready before processing requests"""
    # Allow health check endpoint
    if request.endpoint == 'health':
        return None
    
    if not db_ready.is_set():
        if request.headers.get('Accept', '').startswith('application/json'):
            return jsonify({"status": "starting", "message": "Service is starting, please wait..."}), 503
        else:
            return render_template_string("""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Admin Service Starting</title>
                <meta http-equiv="refresh" content="5">
                <style>
                    body { font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }
                    .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 2s linear infinite; margin: 20px auto; }
                    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                </style>
            </head>
            <body>
                <h1>Admin Service Starting</h1>
                <div class="spinner"></div>
                <p>The service is initializing. Please wait...</p>
                <p>This page will refresh automatically.</p>
            </body>
            </html>
            """), 503

@app.route("/health")
def health():
    """Health check endpoint"""
    if db_ready.is_set():
        return jsonify({"status": "healthy", "database": "ready"}), 200
    else:
        return jsonify({"status": "starting", "database": "not_ready"}), 503

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        uname = request.form["username"]
        pwd   = request.form["password"]

        user = User.query.filter_by(username=uname).first()
        if user and user.is_admin and bcrypt.checkpw(f"{uname}{pwd}".encode(), user.pw_hash):
            session["user_id"] = user.id
            session["username"] = user.username
            return redirect(url_for("welcome"))
        flash("Invalid admin credentials.", "danger")

    return render_template("login.html")

@app.route("/welcome")
def welcome():
    if not session.get("user_id"):
        return redirect(url_for("login"))
    flag = os.environ.get("FLAG", "Could not find flag")
    return render_template("welcome.html", username=session["username"], flag = flag)
