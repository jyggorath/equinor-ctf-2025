from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import event
import re
from hashlib import sha256

db = SQLAlchemy()


class User(db.Model):
    __tablename__ = "users"
    id       = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(255), unique=True, nullable=False)
    pw_hash  = db.Column(db.LargeBinary, nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)

    def __repr__(self):
        return f"<User {self.username} {'(admin)' if self.is_admin else ''}>"

class ConvertedRule(db.Model):
    __tablename__ = "converted_rules"
    id                      = db.Column(db.Integer, primary_key=True)
    user_id                 = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    title                   = db.Column(db.String(255))
    category                = db.Column(db.String(100))
    product                 = db.Column(db.String(100))
    original_yaml           = db.Column(db.Text)
    converted_kql           = db.Column(db.Text)
    converted_kql_signature = db.Column(db.Text)
    created_at              = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    is_favorite             = db.Column(db.Boolean, default=False, nullable=False)

    user = db.relationship("User", backref="converted_rules")

    def get_signature(self):
        if not self.converted_kql:
            return None
        cleaned = re.sub(r'[\r\n]+', ' ', self.converted_kql)
        cleaned = cleaned.replace('%', '').replace('_', '').replace('\\', '')
        cleaned = re.sub(r'\s+', ' ', cleaned).strip()
        return sha256(cleaned.encode("utf-8")).hexdigest() + cleaned

    def update_signature(self):
        if not self.converted_kql:
            self.converted_kql_signature = None
            return
        self.converted_kql_signature = self.get_signature() or None

@event.listens_for(ConvertedRule, "before_insert")
def _cr_before_insert(mapper, connection, target):
    target.update_signature()

@event.listens_for(ConvertedRule, "before_update")
def _cr_before_update(mapper, connection, target):
    # Only recompute if source changed
    state = db.inspect(target)
    if 'converted_kql' in state.attrs and state.attrs.converted_kql.history.has_changes():
        target.update_signature()

class CombinedRuleSet(db.Model):
    __tablename__ = "combined_rule_set"
    id           = db.Column(db.Integer, primary_key=True)
    user_id                 = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    combined_kql            = db.Column(db.Text, nullable=False)
    combined_kql_signature  = db.Column(db.Text, nullable=False)
    created_at              = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

    user = db.relationship("User", backref="combined_rule_sets")
