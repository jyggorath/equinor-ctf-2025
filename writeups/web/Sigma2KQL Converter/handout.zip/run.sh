#!/bin/bash

# Usage: ./run.sh [-d|--detached]

DETACHED=""

if [[ "$1" == "-d" || "$1" == "--detached" ]]; then
  DETACHED="-d"
  echo "🚀 Running in detached mode..."
else
  echo "🚀 Running in foreground mode..."
fi

docker compose up --build $DETACHED
