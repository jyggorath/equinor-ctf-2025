import os, time, threading, secrets
from flask import Flask, request, jsonify, render_template_string
from werkzeug.middleware.proxy_fix import ProxyFix
from models import db
from sqlalchemy.exc import OperationalError
from sqlalchemy import text
import psycopg2
import logging, sys

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
sys.stdout.reconfigure(line_buffering=True)

app = Flask(__name__)
portal_secret = os.getenv("PORTAL_SECRET")
if not portal_secret:
    raise RuntimeError("PORTAL_SECRET environment variable is required but not set. Refuse to start for security reasons.")

app_generated_key = secrets.token_hex(32)  # 32 bytes = 256 bits of entropy
app.secret_key = portal_secret + app_generated_key
app.config['APPLICATION_ROOT'] = '/portal'

# Configure for reverse proxy (nginx/load balancer)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1, x_prefix=1)

app.config['PREFERRED_URL_SCHEME'] = 'http'
app.config['SERVER_NAME'] = None

SQLALCHEMY_DATABASE_URI = (
    f"postgresql://{os.getenv('DB_USER')}:{os.getenv('DB_PASS')}@{os.getenv('DB_HOST')}/{os.getenv('DB_NAME')}?options=-cstatement_timeout=2000"
)
app.config["SQLALCHEMY_DATABASE_URI"] = (SQLALCHEMY_DATABASE_URI)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Global flag to track database readiness
db_ready = threading.Event()

def check_db_connection():
    """Check if database connection is ready"""
    try:
        with app.app_context():
            with db.engine.connect() as connection:
                connection.execute(text("SELECT 1"))
        return True
    except (OperationalError, psycopg2.OperationalError, Exception):
        return False

def wait_for_db_background():
    """Background thread to wait for database"""
    app.logger.info("Portal service starting - checking database connection...")
    max_retries = 60
    initial_delay = 1
    max_delay = 10
    
    for attempt in range(max_retries):
        if check_db_connection():
            app.logger.info(f"Database is ready! Portal service fully operational (attempt {attempt + 1})")
            db_ready.set()
            return
        
        delay = min(initial_delay * (1.5 ** attempt), max_delay)
        app.logger.info(f"Database not ready (attempt {attempt + 1}/{max_retries}). Retrying in {delay:.1f}s")
        time.sleep(delay)
    
    app.logger.error("Database connection failed after all retries. Service will remain in starting state.")

# Start background database check
threading.Thread(target=wait_for_db_background, daemon=True).start()

@app.before_request
def check_service_ready():
    """Check if service is ready before processing requests"""
    # Allow health check endpoint
    if request.endpoint == 'health':
        return None
    
    if not db_ready.is_set():
        if request.headers.get('Accept', '').startswith('application/json'):
            return jsonify({"status": "starting", "message": "Service is starting, please wait..."}), 503
        else:
            return render_template_string("""
            <!DOCTYPE html>
            <html>
            <head>
                <title>Portal Service Starting</title>
                <meta http-equiv="refresh" content="5">
                <style>
                    body { font-family: Arial, sans-serif; text-align: center; margin-top: 100px; }
                    .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; width: 40px; height: 40px; animation: spin 2s linear infinite; margin: 20px auto; }
                    @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                </style>
            </head>
            <body>
                <h1>Portal Service Starting</h1>
                <div class="spinner"></div>
                <p>The service is initializing. Please wait...</p>
                <p>This page will refresh automatically.</p>
            </body>
            </html>
            """), 503

@app.route("/health")
def health():
    """Health check endpoint"""
    if db_ready.is_set():
        return jsonify({"status": "healthy", "database": "ready"}), 200
    else:
        return jsonify({"status": "starting", "database": "not_ready"}), 503


# register blueprints

from auth import bp as auth_bp
from main import bp as main_bp
app.register_blueprint(auth_bp)
app.register_blueprint(main_bp)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
