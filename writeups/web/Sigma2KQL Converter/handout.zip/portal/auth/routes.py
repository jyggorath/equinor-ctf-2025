import bcrypt
from flask import (
    render_template, request, redirect,
    url_for, flash, session
)
from sqlalchemy.exc import IntegrityError
from . import bp
from models import db, User


# ────────────  session helpers  ─────────────────────────────────────────
def _login(user: User):
    session.update(
        user_id=user.id,
        username=user.username,
        is_admin=user.is_admin,
    )


def _logout():
    session.clear()


# ────────────  register / login / logout  ──────────────────────────────
@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        uname = request.form["username"].strip()   # e-mail
        pwd   = request.form["password"]
        if len(pwd) < 20:
            flash("Password must be at least 20 characters long.", "danger")
            return render_template("register.html")
        pw_hash = bcrypt.hashpw(f"{uname}{pwd}".encode(), bcrypt.gensalt())
        try:
            db.session.add(User(username=uname, pw_hash=pw_hash))
            db.session.commit()
            flash("Registration successful - please log in.", "success")
            return redirect(url_for("auth.login"))
        except IntegrityError:
            db.session.rollback()
            flash("User already exists.", "danger")

    return render_template("register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        uname = request.form["username"].strip()
        pwd   = request.form["password"]
        if len(pwd) < 20:
            flash("Password must be at least 20 characters long.", "danger")
            return render_template("register.html")
        user = User.query.filter_by(username=uname).first()
        if user and bcrypt.checkpw(f"{uname}{pwd}".encode(), user.pw_hash):
            _login(user)
            return redirect(url_for("main.index"))

        flash("Invalid credentials", "danger")
    return render_template("login.html")


@bp.route("/logout")
def logout():
    _logout()
    flash("Logged out.", "info")
    return redirect(url_for("auth.login"))
