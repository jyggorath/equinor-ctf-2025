from functools import wraps
from flask import (
    render_template, session, redirect,
    url_for, flash, request, jsonify, abort
)
from . import bp
from models import db, ConvertedRule, CombinedRuleSet
from sqlalchemy import text


# ───────────────  login-required decorator  ────────────────────────────
def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("auth.login"))
        return f(*args, **kwargs)
    return wrapped


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in.", "warning")
            return redirect(url_for("auth.login"))
        if not session.get("is_admin"):
            abort(403)  # Forbidden
        return f(*args, **kwargs)
    return decorated


# ───────────────  pages  ───────────────────────────────────────────────
@bp.route("/")
@login_required
def index():
    return render_template("index.html", username=session["username"])

from sigma.rule import SigmaRule
from sigma.backends.kusto import KustoBackend
from sigma.pipelines.microsoftxdr import microsoft_xdr_pipeline
xdr_pipeline = microsoft_xdr_pipeline()
backend = KustoBackend(processing_pipeline=xdr_pipeline)
@bp.route("/convert_yaml", methods=["POST"])
@login_required
def convert_yaml():
    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    try:
        rule = SigmaRule.from_yaml(text)
        kql = backend.convert_rule(rule)[0]
        title = rule.title or "Untitled"
        logsource = rule.logsource
        category = getattr(logsource, "category", None)
        product = getattr(logsource, "product", None)
                # Save to DB
        converted = ConvertedRule(
            user_id=session["user_id"],
            title=title,
            category=category,
            product=product,
            original_yaml=text,
            converted_kql=kql,
        )
        db.session.add(converted)
        db.session.commit()
        return jsonify(title=rule.title, kql=kql)

    except Exception as e:
        return jsonify(title="Error", kql=f"Error converting rule:\n{e}")

@bp.route("/my-rules")
@login_required
def my_rules():
    user_id = session["user_id"]
    category_filter = request.args.get("category")
    product_filter  = request.args.get("product")
    favorites_only  = request.args.get("favorites") == "1"

    # Switch to ORM query for safety
    query = ConvertedRule.query.filter(ConvertedRule.user_id == user_id)
    if category_filter:
        query = query.filter(ConvertedRule.category == category_filter)
    if product_filter:
        query = query.filter(ConvertedRule.product == product_filter)
    if favorites_only:
        query = query.filter(ConvertedRule.is_favorite.is_(True))
    rules = query.order_by(ConvertedRule.created_at.desc()).all()

    # for filter dropdowns
    categories = (
        db.session.query(ConvertedRule.category)
        .filter(ConvertedRule.user_id == user_id)
        .distinct()
        .order_by(ConvertedRule.category)
        .all()
    )
    products = (
        db.session.query(ConvertedRule.product)
        .filter(ConvertedRule.user_id == user_id)
        .distinct()
        .order_by(ConvertedRule.product)
        .all()
    )

    return render_template(
        "my_rules.html",
        rules=rules,
        categories=[c[0] for c in categories if c[0]],
        products=[p[0] for p in products if p[0]],
        current_category=category_filter,
        current_product=product_filter,
        favorites_only=favorites_only,
    )

@bp.route("/toggle-favorite/<int:rule_id>", methods=["POST"])
@login_required
def toggle_favorite(rule_id):
    user_id = session["user_id"]
    rule = ConvertedRule.query.filter_by(id=rule_id, user_id=user_id).first_or_404()
    try:
        rule.is_favorite = not rule.is_favorite
        db.session.commit()
        return jsonify({"success": True, "is_favorite": rule.is_favorite})
    except Exception:
        db.session.rollback()
        return jsonify({"success": False}), 500

@bp.route("/delete-all-rules", methods=["POST"])
@login_required
def delete_all_rules():
    user_id = session["user_id"]
    try:
        # Delete all rules for the current user
        ConvertedRule.query.filter_by(user_id=user_id).delete()
        db.session.commit()
        flash("All your rules have been successfully deleted.", "success")
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while deleting your rules. Please try again.", "danger")
    
    return redirect(url_for("main.my_rules"))

@bp.route("/combine-rules", methods=["POST"])
@login_required
def combine_rules():
    user_id = session["user_id"]
    rule_ids = request.form.getlist("selected_rules")
    
    if len(rule_ids) < 2:
        flash("Please select at least 2 rules to combine.", "warning")
        return redirect(url_for("main.my_rules"))
    
    try:
        # Get the selected rules with their KQL and titles using SQLAlchemy ORM
        rule_ids_int = [int(rule_id) for rule_id in rule_ids]
        rows = (ConvertedRule.query
                .filter(ConvertedRule.user_id == user_id)
                .filter(ConvertedRule.id.in_(rule_ids_int))
                .order_by(ConvertedRule.created_at)
                .all())
        
        if len(rows) < 2:
            flash("Could not find enough valid rules to combine.", "warning")
            return redirect(url_for("main.my_rules"))
        
        converted_kql_rules = []
        converted_kql_signature_rules = []
        for r in rows:
            branch = f"({r.converted_kql}) | extend RuleTitle='{r.title}'"
            converted_kql_rules.append(branch)
            branch_signature = f"({r.converted_kql_signature}) | extend RuleTitle='{r.title}'"
            converted_kql_signature_rules.append(branch_signature)

        combined_kql = "\n| union \n".join(converted_kql_rules) + "\n| project *, RuleTitle"
        combined_kql_signature = "\n| union \n".join(converted_kql_signature_rules) + "\n| project *, RuleTitle"
        
        new_set = CombinedRuleSet(user_id=user_id, combined_kql=combined_kql, combined_kql_signature=combined_kql_signature )
        db.session.add(new_set)
        db.session.commit()
        
        flash(f"Successfully combined {len(rows)} rules into a multi-signature threat hunting query!", "success")
        
    except Exception as e:
        db.session.rollback()
        flash("An error occurred while combining rules. Please try again.", "danger")
    
    return redirect(url_for("main.my_rules"))

@bp.route("/combined-rules")
@login_required
def combined_rules():
    user_id = session["user_id"]
    
    # Get all combined rule sets for the current user
    combined_rules = (CombinedRuleSet.query
                      .filter(CombinedRuleSet.user_id == user_id)
                      .order_by(CombinedRuleSet.created_at.desc())
                      .all())
    
    return render_template("combined_rules.html", combined_rules=combined_rules)

@bp.route("/api/combined-rules/favorites-status")
@login_required
def api_combined_rules_favorites_status():
    user_id = session["user_id"]
    converted_rules = (
        db.session.query(ConvertedRule.converted_kql_signature)
        .filter(ConvertedRule.user_id == user_id)
        .filter(ConvertedRule.is_favorite.is_(True))
        .filter(ConvertedRule.converted_kql.isnot(None))
        .filter(ConvertedRule.converted_kql != "")
        .all()
    )
    like_clauses = []
    for (converted_kql_signature,) in converted_rules:
        if not converted_kql_signature or not converted_kql_signature.strip():
            continue
        like_clauses.append(f"combined_kql_signature LIKE '%{converted_kql_signature}%'")
    if not like_clauses:
        return jsonify({"favorite_set_ids": []})

    where_fragment = " OR ".join(like_clauses)
    combined_rule_set_containing_favorites = f"""
        SELECT id FROM combined_rule_set
        WHERE user_id = {int(user_id)} AND ( {where_fragment} )
    """
    result = db.session.execute(text(combined_rule_set_containing_favorites)).fetchall()
    ids = [row[0] for row in result]
    return jsonify({"favorite_set_ids": ids})