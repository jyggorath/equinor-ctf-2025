from flask import Flask, render_template, request, jsonify, redirect, url_for, make_response
import sqlite3
import hashlib
import secrets
import os
import asyncio
import threading
from playwright.async_api import async_playwright

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-prod')
FLAG = os.environ.get('FLAG', 'EPT{this_is_a_fake_flag}')
ADMIN_SESSION = os.environ.get('ADMIN_SESSION', secrets.token_urlsafe(32))

DATABASE = '/tmp/cloudnotes.db'

def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    db = get_db()
    
    db.executescript('''
        DROP TABLE IF EXISTS users;
        DROP TABLE IF EXISTS notes;
        
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            session_token TEXT
        );
        
        CREATE TABLE notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        );
    ''')
    
    admin_password = hashlib.sha256(('admin-super-secret-password-' + app.config['SECRET_KEY']).encode()).hexdigest()
    db.execute('INSERT INTO users (username, password, session_token) VALUES (?, ?, ?)',
               ('admin', admin_password, ADMIN_SESSION))
    
    db.execute('INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)',
               (1, 'Server Maintenance', 'Reminder: Database backup scheduled for next Tuesday at 2 AM.'))
    db.execute('INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)',
               (1, 'Q4 Planning', 'Discuss Q4 roadmap with team. Focus on security improvements.'))
    db.execute('INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)',
               (1, 'API Keys', FLAG))
    
    db.commit()
    db.close()

def get_current_user():
    session_token = request.cookies.get('session')
    if not session_token:
        return None
    
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE session_token = ?', (session_token,)).fetchone()
    db.close()
    return user

@app.route('/')
def index():
    user = get_current_user()
    if user:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    session_token = secrets.token_urlsafe(32)
    
    db = get_db()
    try:
        db.execute('INSERT INTO users (username, password, session_token) VALUES (?, ?, ?)',
                   (username, password_hash, session_token))
        db.commit()
    except sqlite3.IntegrityError:
        db.close()
        return jsonify({'error': 'Username already exists'}), 400
    
    db.close()
    
    response = make_response(jsonify({'success': True, 'redirect': '/dashboard'}))
    response.set_cookie('session', session_token, httponly=True, samesite='Lax')
    return response

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    
    db = get_db()
    user = db.execute('SELECT * FROM users WHERE username = ? AND password = ?',
                      (username, password_hash)).fetchone()
    db.close()
    
    if not user:
        return jsonify({'error': 'Invalid credentials'}), 401
    
    response = make_response(jsonify({'success': True, 'redirect': '/dashboard'}))
    response.set_cookie('session', user['session_token'], httponly=True, samesite='Lax')
    return response

@app.route('/dashboard')
def dashboard():
    user = get_current_user()
    if not user:
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=user['username'])

@app.route('/logout', methods=['POST'])
def logout():
    response = make_response(redirect(url_for('index')))
    response.set_cookie('session', '', expires=0)
    return response

@app.route('/api/notes', methods=['GET', 'POST'])
def notes():
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Unauthorized'}), 401
    
    if request.method == 'GET':
        db = get_db()
        notes = db.execute('''
            SELECT id, user_id, title, content, created_at 
            FROM notes 
            WHERE user_id = ? 
            ORDER BY created_at DESC
        ''', (user['id'],)).fetchall()
        db.close()
        
        return jsonify([dict(note) for note in notes])
    
    data = request.get_json()
    title = data.get('title', 'Untitled')
    content = data.get('content', '')
    
    db = get_db()
    
    fields = ['title', 'content']
    values = [title, content]
    
    if 'user_id' in data:
        fields.append('user_id')
        values.append(data['user_id'])
    else:
        fields.append('user_id')
        values.append(user['id'])
    
    query = f"INSERT INTO notes ({', '.join(fields)}) VALUES ({', '.join(['?' for _ in fields])})"
    cursor = db.execute(query, values)
    note_id = cursor.lastrowid
    db.commit()
    db.close()
    
    return jsonify({'id': note_id, 'success': True})

VISIT_INTERVAL = int(os.getenv('VISIT_INTERVAL', '30'))
_last_seen_note_id = 0

def get_latest_admin_note_id():
    db = get_db()
    result = db.execute('SELECT MAX(id) as max_id FROM notes WHERE user_id = 1').fetchone()
    db.close()
    return result['max_id'] if result['max_id'] else 0

async def visit_dashboard():
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(
            headless=True,
            args=[
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
            ]
        )
        
        context = await browser.new_context()
        page = None

        try:
            page = await context.new_page()

            raw_password = 'admin-super-secret-password-' + app.config['SECRET_KEY']
            login_status = await page.evaluate(
                "(pwd)=>fetch('http://localhost:5000/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'admin',password:pwd})}).then(r=>r.status).catch(_=>-1)",
                raw_password
            )

            if login_status != 200:
                await context.add_cookies([{
                    'name': 'session',
                    'value': ADMIN_SESSION,
                    'path': '/',
                    'httpOnly': True,
                    'secure': False,
                    'sameSite': 'Lax',
                    'domain': 'localhost'
                }])
                await page.goto('http://localhost:5000/dashboard', wait_until='networkidle', timeout=20000)
            else:
                await page.goto('http://localhost:5000/dashboard', wait_until='networkidle', timeout=20000)

            await asyncio.sleep(5)

        except Exception as e:
            print(f'[Bot] Error: {type(e).__name__}')
        finally:
            if page:
                await page.close()
            await context.close()
            await browser.close()

def bot_loop():
    global _last_seen_note_id
    
    import time
    time.sleep(5)
    
    _last_seen_note_id = get_latest_admin_note_id()
    
    while True:
        try:
            latest_note_id = get_latest_admin_note_id()
            if latest_note_id > _last_seen_note_id:
                asyncio.run(visit_dashboard())
                _last_seen_note_id = latest_note_id
        except Exception as e:
            pass
        
        time.sleep(VISIT_INTERVAL)

if __name__ == '__main__':
    init_db()
    
    bot_thread = threading.Thread(target=bot_loop, daemon=True)
    bot_thread.start()
    
    app.run(host='0.0.0.0', port=5000, debug=False)
