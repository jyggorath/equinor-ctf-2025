// Authentication functions
async function handleAuth(endpoint, formId) {
    const form = document.getElementById(formId);
    const errorDiv = document.getElementById('error-message');
    
    const formData = new FormData(form);
    const data = {
        username: formData.get('username'),
        password: formData.get('password')
    };
    
    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (response.ok) {
            window.location.href = result.redirect;
        } else {
            errorDiv.textContent = result.error || 'An error occurred';
            errorDiv.style.display = 'block';
        }
    } catch (error) {
        errorDiv.textContent = 'Network error occurred';
        errorDiv.style.display = 'block';
    }
}

// Dashboard functions
let notes = [];

async function loadNotes() {
    try {
        const response = await fetch('/api/notes');
        notes = await response.json();
        renderNotes();
    } catch (error) {
        console.error('Failed to load notes:', error);
    }
}

function renderNotes() {
    const grid = document.getElementById('notes-grid');
    
    if (notes.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <p>No notes yet. Create your first note above!</p>
            </div>
        `;
        return;
    }
    
    const notesHtml = notes.map(note => `
        <div class="note-card" data-note-id="${note.id}">
            <div class="note-header">
                <h3 class="note-title">${escapeHtml(note.title)}</h3>
            </div>
            <div class="note-content">${note.content}</div>
            <div class="note-meta">Created: ${new Date(note.created_at).toLocaleString()}</div>
        </div>
    `).join('');

    grid.innerHTML = notesHtml;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

async function createNote() {
    const title = document.getElementById('note-title').value;
    const content = document.getElementById('note-content').value;
    
    if (!title.trim() || !content.trim()) {
        alert('Please fill in both title and content');
        return;
    }
    
    try {
        const response = await fetch('/api/notes', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ title, content })
        });
        
        if (response.ok) {
            document.getElementById('note-title').value = '';
            document.getElementById('note-content').value = '';
            await loadNotes();
        }
    } catch (error) {
        console.error('Failed to create note:', error);
        alert('Failed to create note');
    }
}

// Initialize dashboard
if (document.getElementById('notes-grid')) {
    loadNotes();
}
