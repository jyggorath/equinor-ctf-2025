import os
import secrets
import sqlite3

from flask import Flask, g, redirect, render_template, request

app = Flask(__name__)


def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect("shop.db")
    return db


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()


def init_db():
    FLAG = os.getenv("FLAG")
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.executescript(f"""
            DROP TABLE IF EXISTS users;
            DROP TABLE IF EXISTS items;
            DROP TABLE IF EXISTS activity;

            CREATE TABLE users (
                id TEXT PRIMARY KEY,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE items (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                details TEXT,
                image TEXT,
                price INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            INSERT INTO items (id, name, description, details, image, price) VALUES
            ('joke', 'Joke', 'Knock knock', 'Who''s there?', '/joke.png', 99),
            ('life-advice', 'Life Advice', 'Invaluable life advice for any CTF player no matter their skill level!', 'If a challenge seems too hard to solve, simply try a bit harder!', '/advice.png', 199),
            ('usb-cable', 'USB Cable NFT', 'High-speed USB-C charging cable.', 'This NFT version allows you to claim your digital USB cable backed by the real time and zero-gas EPT chain using military grade encryption!', '/usb.png', 313),
            ('sticky-notes', 'Sticky Notes NFT', 'Pack of colorful sticky notes for organization.', 'This NFT version allows you to claim your digital sticky notes backed by the real time and zero-gas EPT chain using military grade encryption!', '/notes.png', 420),
            ('pen', 'Pen NFT', 'Smooth-writing ballpoint pen.', 'This NFT version allows you to claim your digital pen backed by the real time and zero-gas EPT chain using military grade encryption!', '/pen.png', 512),
            ('calculator', 'Calculator NFT', 'Scientific calculator for complex calculations.', 'This NFT version allows you to claim your digital calculator backed by the real time and zero-gas EPT chain using military grade encryption!', '/calc.png', 609),
            ('notebook', 'Notebook NFT', 'Spiral-bound notebook for taking notes.', 'This NFT version allows you to claim your digital notebook backed by the real time and zero-gas EPT chain using military grade encryption!', '/notebook.png', 696),
            ('desk-lamp', 'Desk Lamp NFT', 'Adjustable LED desk lamp.', 'This NFT version allows you to claim your digital desk lamp backed by the real time and zero-gas EPT chain using military grade encryption!', '/lamp.png', 720),
            ('mousepad', 'Mousepad NFT', 'Large gaming mousepad with RGB lighting.', 'This NFT version allows you to claim your digital mousepad backed by the real time and zero-gas EPT chain using military grade encryption!', '/mousepad.png', 842),
            ('webcam', 'Webcam NFT', 'HD webcam for video calls and streaming.', 'This NFT version allows you to claim your digital webcam backed by the real time and zero-gas EPT chain using military grade encryption!', '/webcam.png', 906),
            ('phone-stand', 'Phone Stand NFT', 'Adjustable phone stand for desk use.', 'This NFT version allows you to claim your digital phone stand backed by the real time and zero-gas EPT chain using military grade encryption!', '/stand.png', 1010),
            ('speakers', 'Speakers NFT', 'Compact desktop speakers with clear sound.', 'This NFT version allows you to claim your digital speakers backed by the real time and zero-gas EPT chain using military grade encryption!', '/speakers.png', 1111),
            ('energy-drink', 'Energy Drink NFT', 'Caffeinated beverage for late-night coding.', 'This NFT version allows you to claim your digital energy drink backed by the real time and zero-gas EPT chain using military grade encryption!', '/energy.png', 1234),
            ('ept-totebag', 'EPT Totebag', 'A real life EPT Totebag!', 'Claim one for free at the at the stage IRL using the following cupon code: {FLAG}', '/totebag.png', 1337),
            ('headphones', 'Headphones NFT', 'High-quality headphones with noise-cancelling feature.', 'This NFT version allows you to claim your digital headphones backed by the real time and zero-gas EPT chain using military grade encryption!', '/headphones.png', 1599),
            ('wireless-mouse', 'Wireless Mouse NFT', 'Ergonomic wireless mouse with USB receiver.', 'This NFT version allows you to claim your digital mouse backed by the real time and zero-gas EPT chain using military grade encryption!', '/mouse.png', 2999),
            ('laptop', 'Laptop NFT', 'High-performance laptop for work and gaming.', 'This NFT version allows you to claim your digital laptop backed by the real time and zero-gas EPT chain using military grade encryption!', '/laptop.png', 9999);

            CREATE TABLE activity (
                session_id TEXT,
                item_id TEXT,
                type TEXT CHECK(type IN ('buy', 'sell')) NOT NULL,
                transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES items(id),
                FOREIGN KEY (session_id) REFERENCES users(id)
            );
        """)
        db.commit()


@app.before_request
def ensure_user():
    session_id = request.cookies.get("session_id")
    if not session_id:
        session_id = secrets.token_urlsafe(32)
        db = get_db()
        cursor = db.cursor()
        cursor.execute("INSERT INTO users (id) VALUES (?)", (session_id,))
        db.commit()
        g.new_session_id = session_id
    g.session_id = session_id


@app.after_request
def set_session_cookie(response):
    if hasattr(g, "new_session_id"):
        response.set_cookie("session_id", g.new_session_id, httponly=True, secure=False)
    return response


@app.route("/")
def index():
    db = get_db()
    cursor = db.cursor()
    items = cursor.execute("SELECT * FROM items ORDER BY created_at DESC").fetchall()
    items = {item[0]: item[5] for item in items}
    activity = cursor.execute("SELECT * FROM activity WHERE session_id = ? ORDER BY transaction_date ASC", (g.session_id,))
    activity = activity.fetchall()
    balance = 137
    for activity in activity:
        if activity[2] == "buy":
            balance -= items[activity[1]]
        elif activity[2] == "sell":
            balance += items[activity[1]]
    return render_template("index.html", items=[item for item in items], balance=balance)


@app.route("/activity", methods=["POST"])
def activity():
    db = get_db()
    cursor = db.cursor()
    activity = cursor.execute("SELECT * FROM activity WHERE session_id = ? ORDER BY transaction_date ASC", (g.session_id,))
    activity = activity.fetchall()
    items = cursor.execute("SELECT * FROM items ORDER BY created_at DESC").fetchall()
    items = {item[0]: item[5] for item in items}
    if "sell" in request.form:
        item_id = request.form.get("sell")
        owned = 0
        for activity in activity:
            if activity[1] == item_id:
                if activity[2] == "buy":
                    owned += 1
                elif activity[2] == "sell":
                    owned -= 1
        if owned >= 1:
            cursor.execute("INSERT INTO activity (session_id, item_id, type) VALUES (?, ?, 'sell')", (g.session_id, item_id))
            activity = [*activity, (g.session_id, item_id, "sell")]
            db.commit()
        else:
            return redirect("/")
    if "buy" in request.form:
        item_id = request.form.get("buy")
        balance = 137
        for activity in activity:
            if activity[2] == "buy":
                balance -= items[activity[1]]
            elif activity[2] == "sell":
                balance += items[activity[1]]
        if balance >= items[item_id]:
            cursor.execute("INSERT INTO activity (session_id, item_id, type) VALUES (?, ?, 'buy')", (g.session_id, item_id))
            activity = [*activity, (g.session_id, item_id, "buy")]
            db.commit()
        else:
            return redirect("/")
    return redirect("/")


@app.route("/item")
def item():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM items ORDER BY created_at ASC")
    items = cursor.fetchall()
    cursor.execute("SELECT * FROM activity WHERE session_id = ? ORDER BY transaction_date ASC", (g.session_id,))
    activity = cursor.fetchall()
    details = request.args.get("details")
    if details:
        owned = 0
        for activity in activity:
            if activity[1] == details:
                if activity[2] == "buy":
                    owned += 1
                elif activity[2] == "sell":
                    owned -= 1
        for item in items:
            if item[0] == details:
                return {"owned": owned, "item": {"id": item[0], "name": item[1], "description": item[2], "details": item[3] if owned > 0 else None, "image": item[4], "price": item[5]}}
    preview = request.args.get("preview")
    if preview:
        for item in items:
            if item[0] == preview:
                return {"id": item[0], "name": item[1], "description": item[2], "image": item[4], "price": item[5]}
    return redirect("/")


@app.route("/inventory")
def inventory():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM activity WHERE session_id = ? ORDER BY transaction_date ASC", (g.session_id,))
    activity = cursor.fetchall()
    owned_items = {}
    for activity in activity:
        if owned_items.get(activity[1]) is None:
            owned_items[activity[1]] = 0
        if activity[2] == "buy":
            owned_items[activity[1]] += 1
        elif activity[2] == "sell":
            owned_items[activity[1]] -= 1
    owned_items = {k: v for k, v in owned_items.items() if v > 0}
    return render_template("inventory.html", owned_items=owned_items)


if __name__ == "__main__":
    init_db()
    app.run(threaded=False, host="0.0.0.0", port=1337)
