DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS bookings;

CREATE TABLE movies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    available_seats INTEGER NOT NULL,
    image_path TEXT,
    rating TEXT,
    genre TEXT,
    duration TEXT,
    showtimes TEXT
);

CREATE TABLE bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    movie_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    tickets INTEGER NOT NULL,
    showtime TEXT,
    FOREIGN KEY
(movie_id) REFERENCES movies
(id)
);

INSERT INTO movies
    (title, available_seats, image_path, rating, genre, duration, showtimes)
VALUES
    ("Inception", 50, "img/inception.jpg", "PG-13", "Sci-Fi, Thriller", "2h 28m", "7:00 PM,9:30 PM"),
    ("The Matrix", 40, "img/matrix.jpg", "R", "Action, Sci-Fi", "2h 16m", "6:30 PM,9:00 PM"),
    ("Interstellar", 60, "img/interstellar.jpg", "PG-13", "Sci-Fi, Drama", "2h 49m", "7:15 PM,10:00 PM"),
    ("The Dark Knight", 30, "img/dark_knight.jpg", "PG-13", "Action, Crime, Drama", "2h 32m", "7:00 PM,9:45 PM"),
    ("Pulp Fiction", 25, "img/pulp_fiction.jpg", "R", "Crime, Drama", "2h 34m", "6:45 PM,9:15 PM"),
    ("Forrest Gump", 55, "img/forrest_gump.jpg", "PG-13", "Drama, Romance", "2h 22m", "6:00 PM,8:45 PM");
