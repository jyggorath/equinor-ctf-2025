# Flask Movie Ticket Booking App

## Setup

```bash
python3 -m venv venv
source venv/bin/activate
pip install flask
sqlite3 database.db < schema.sql
python app.py
```

Visit http://127.0.0.1:5000 to use the app.