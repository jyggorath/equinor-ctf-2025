class Config:
    DATABASE = "database.db"