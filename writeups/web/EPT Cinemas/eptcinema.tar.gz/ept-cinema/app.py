from flask import Flask, render_template, request, redirect, url_for, g
import sqlite3

app = Flask(__name__)
app.config.from_object("config.Config")

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

@app.route("/")
def index():
    conn = get_db()
    movies = conn.execute("SELECT * FROM movies").fetchall()
    return render_template("index.html", movies=movies)

@app.route("/book/<string:movie_id>", methods=["GET", "POST"])
def book(movie_id):
    conn = get_db()
    movie = conn.execute("SELECT * FROM movies WHERE id = "+str(movie_id)).fetchone()
  

    if request.method == "POST":
        name = request.form["name"]
        tickets = int(request.form["tickets"])
        showtime = request.form["showtime"]
        
        if tickets > 0 and tickets <= movie["available_seats"]:
            conn.execute(
                "UPDATE movies SET available_seats = available_seats - ? WHERE id = ?",
                (tickets, movie_id),
            )
            conn.execute(
                "INSERT INTO bookings (movie_id, name, tickets, showtime) VALUES (?, ?, ?, ?)",
                (movie_id, name, tickets, showtime),
            )
            conn.commit()
            return redirect(url_for("confirmation", movie_title=movie["title"], name=name, tickets=tickets, showtime=showtime))
        else:
            return render_template("book.html", movie=movie, error="Invalid number of tickets.")

    return render_template("book.html", movie=movie)

@app.route("/confirmation")
def confirmation():
    movie_title = request.args.get("movie_title", "Unknown Movie")
    name = request.args.get("name", "Guest")
    tickets = request.args.get("tickets", "0")
    showtime = request.args.get("showtime", "N/A")
    return render_template("confirmation.html", movie_title=movie_title, name=name, tickets=tickets, showtime=showtime)

