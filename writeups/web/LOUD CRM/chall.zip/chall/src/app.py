import logging
import os
import secrets
from functools import wraps

from flask import Flask, redirect, render_template, request, session, url_for, flash

from . import auth
from .data import get_demo_leads


def create_app() -> Flask:
    app = Flask(
        __name__,
        static_folder="static",
        template_folder="templates",
    )

    app.logger.setLevel(logging.INFO)

    secret_key = os.environ.get("SECRET_KEY")
    if not secret_key:
        secret_key = secrets.token_hex(16)
        app.logger.debug("Generated ephemeral SECRET_KEY for session management")
    app.config["SECRET_KEY"] = secret_key

    flag_value = os.environ.get("FLAG", "EPT{not_the_flag-you're-looking-for}")
    seed_password = os.environ.get("SEED_PASSWORD", "seed_password")

    auth.seed_user("alice", "Alice Chen", seed_password)

    def login_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "username" not in session:
                flash("Sign in before accessing the dashboard.")
                return redirect(url_for("login"))
            return view(*args, **kwargs)

        return wrapped

    @app.route("/")
    def index():
        return render_template("index.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            display_name = request.form.get("display_name", "").strip()
            password = request.form.get("password", "")

            if not username or not display_name or not password:
                flash("Complete every field before continuing.")
                return render_template("register.html", form=request.form)

            if username == username.upper() and auth.user_exists_upper(username):
                flash("That handle already exists. Choose a different one.")
                return render_template("register.html", form=request.form)

            auth.register_user(username, display_name, password)
            flash("Registration complete. Sign in with your new credentials.")
            return redirect(url_for("login"))

        return render_template("register.html", form={})

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")

            if not username or not password:
                flash("Enter both handle and passphrase.")
                return render_template("login.html", form=request.form)

            user = auth.authenticate(username, password)
            if user:
                session["username"] = username
                session["display_name"] = user.display_name
                flash("Welcome back to the workspace.")
                return redirect(url_for("dashboard"))

            flash("Invalid handle or passphrase. Please try again.")
            return render_template("login.html", form=request.form)

        return render_template("login.html", form={})

    @app.route("/dashboard")
    @login_required
    def dashboard():
        username = session.get("username")
        display_name = session.get("display_name")
        user_record = auth.get_user(username) if username else None

        flag = None
        if username and username.lower() == "alice":
            flag = flag_value

        leads = get_demo_leads()

        return render_template(
            "dashboard.html",
            username=username,
            display_name=display_name or (user_record.display_name if user_record else None),
            flag=flag,
            leads=leads,
        )

    @app.post("/logout")
    def logout():
        session.clear()
        flash("Signed out successfully.")
        return redirect(url_for("index"))

    return app


app = create_app()
