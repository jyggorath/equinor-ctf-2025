from dataclasses import dataclass
from typing import List


@dataclass
class Lead:
    company: str
    contact: str
    vibe_level: int  # 0-100
    notes: str


def get_demo_leads() -> List[Lead]:
    return [
        Lead(
            company="Northwind Logistics",
            contact="Dana Reeves",
            vibe_level=82,
            notes="Requesting quarterly shipment oversight and onboarding support."
        ),
        Lead(
            company="Harborlight Retail",
            contact="Luis Moreno",
            vibe_level=68,
            notes="Pilot program underway for the new sales tracking board."
        ),
        Lead(
            company="Urban Office Supply",
            contact="Priya Patel",
            vibe_level=93,
            notes="Scaling account coverage for five new regional branches."
        ),
    ]
