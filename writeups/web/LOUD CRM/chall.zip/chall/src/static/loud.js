function animateLeadCards() {
    const leadCards = document.querySelectorAll('.lead-card');
    leadCards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('punch');
        }, index * 200);
    });
}

function enforceUppercaseHandles(formSelector) {
    const form = document.querySelector(formSelector);
    if (!form) return;

    const handleInput = form.querySelector('input[name="username"]');
    if (!handleInput) return;

    const forceUppercase = () => {
        const { selectionStart, selectionEnd } = handleInput;
        handleInput.value = handleInput.value.toUpperCase();
        if (selectionStart !== null && selectionEnd !== null) {
            handleInput.setSelectionRange(selectionStart, selectionEnd);
        }
    };

    handleInput.addEventListener('input', forceUppercase);
    form.addEventListener('submit', (event) => {
        forceUppercase();
        if (handleInput.value !== handleInput.value.toUpperCase()) {
            handleInput.setCustomValidity('Handle must be uppercase.');
            handleInput.reportValidity();
            event.preventDefault();
        } else {
            handleInput.setCustomValidity('');
        }
    }, { capture: true });
}

document.addEventListener('DOMContentLoaded', () => {
    animateLeadCards();
    enforceUppercaseHandles('form[data-enforce-uppercase]');
    enforceUppercaseHandles('form[data-force-uppercase]');
});
