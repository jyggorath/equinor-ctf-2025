import logging
from dataclasses import dataclass
from typing import Dict, Optional

from werkzeug.security import check_password_hash, generate_password_hash


logger = logging.getLogger(__name__)


@dataclass
class UserRecord:
    username: str
    display_name: str
    password_hash: str

_users: Dict[str, UserRecord] = {}


def seed_user(username: str, display_name: str, raw_password: str) -> None:
    """Seed a baseline account without announcing it in the UI."""
    register_user(username, display_name, raw_password, announce=False)


def register_user(username: str, display_name: str, raw_password: str, *, announce: bool = True) -> UserRecord:
    username_upper = username.upper() # Store by uppercase key to keep it LOUD
    password_hash = generate_password_hash(raw_password)
    record = UserRecord(username=username_upper, display_name=display_name, password_hash=password_hash)
    _users[username_upper] = record

    if announce:
        logger.info("Registered LOUD CRM user for handle '%s'", username_upper)

    return record


def authenticate(username: str, raw_password: str) -> Optional[UserRecord]:
    record = _users.get(username)
    if not record:
        return None

    if check_password_hash(record.password_hash, raw_password):
        return record

    return None


def get_user(username: Optional[str]) -> Optional[UserRecord]:
    if username is None:
        return None
    return _users.get(username)


def users_snapshot() -> Dict[str, UserRecord]:
    """Return copy for debugging or tests."""
    return dict(_users)


def user_exists_upper(username: str) -> bool:
    return username.upper() in _users
