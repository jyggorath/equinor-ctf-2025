import subprocess

from acr122u import read_card


def process_card(card_data):
    result = subprocess.run(
        ["./badge_decryptor"],
        input=card_data.encode(),
        capture_output=True,
    )
    print(result.stdout.decode())
    if result.stderr:
        print(result.stderr.decode())


if __name__ == "__main__":
    while True:
        card_data = read_card()
        process_card(card_data)
