# PixelPerfect local script validator

## Build & Run

### Docker Compose
```bash
docker compose up --build
```

### Dockerfile
```bash
docker build -t pixelperfect .
docker run -p 5000:5000 pixelperfect
```

Access the application at **http://localhost:5000**
