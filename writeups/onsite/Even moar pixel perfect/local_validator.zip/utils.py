"""
Validation utilities for PixelPerfect CTF
"""


def validate(input_data):
    """
    Validate frames data and yield helpful validation messages.
    
    This function performs various checks on the submitted frames data
    and yields tuples of (check_name, passed, message) for each validation.
    
    Args:
        frames: The frames data to validate (expected to be a list of frames)
        
    Yields:
        tuple: (check_name, passed, message) where:
            - check_name (str): Name of the validation check
            - passed (bool): Whether the check passed
            - message (str): Helpful message about the check result
    """
    # Check 0: Input is a dictionary with "frames" key
    if not isinstance(input_data, dict) or 'frames' not in input_data:
        yield ("Input Type Check", False, f"Input must be a dictionary with 'frames' key, got {type(input_data).__name__}")
        return
    frames = input_data['frames']
    # Check 1: Frames is a list
    if not isinstance(frames, list):
        yield ("Type Check", False, f"Frames must be a list, got {type(frames).__name__}")
        return
    else:
        yield ("Type Check", True, "Frames is a valid list")
    
    # Check 2: Frame count validation (1-300 frames)
    if not (0 < len(frames) <= 300):
        yield ("Frame Count Check", False, f"Must have 1-300 frames, got {len(frames)} frames")
        return
    else:
        yield ("Frame Count Check", True, f"Valid frame count: {len(frames)} frame(s)")
    
    # Check each frame
    for frame_idx, frame in enumerate(frames):
        frame_num = frame_idx + 1
        
        # Check 3: Each frame must have exactly 4 rows
        if not isinstance(frame, list):
            yield ("Frame Structure Check", False, f"Frame #{frame_num} must be a list, got {type(frame).__name__}")
            return
        
        if len(frame) != 4:
            yield ("Frame Dimensions Check", False, f"Frame #{frame_num} must have exactly 4 rows, got {len(frame)} rows")
            return
        
        # Check each row in the frame
        for row_idx, row in enumerate(frame):
            row_num = row_idx + 1
            
            # Check 4: Each row must have exactly 55 pixels
            if not isinstance(row, list):
                yield ("Row Structure Check", False, f"Frame #{frame_num}, row #{row_num} must be a list, got {type(row).__name__}")
                return
            
            if len(row) != 55:
                yield ("Row Length Check", False, f"Frame #{frame_num}, row #{row_num} must have exactly 55 pixels, got {len(row)} pixels")
                return
            
            # Check each pixel in the row
            for px_idx, px in enumerate(row):
                px_num = px_idx + 1
                
                # Check 5: Each pixel must be a list of 3 RGB values
                if not isinstance(px, list):
                    yield ("Pixel Structure Check", False, f"Frame #{frame_num}, row #{row_num}, pixel #{px_num} must be a list, got {type(px).__name__}")
                    return
                
                if len(px) != 3:
                    yield ("RGB Values Check", False, f"Frame #{frame_num}, row #{row_num}, pixel #{px_num} must have exactly 3 RGB values, got {len(px)} values")
                    return
                
                # Check 6: Each RGB value must be 0-255
                for col_idx, col in enumerate(px):
                    color_name = ['R', 'G', 'B'][col_idx]
                    
                    if not isinstance(col, (int, float)):
                        yield ("RGB Type Check", False, f"Frame #{frame_num}, row #{row_num}, pixel #{px_num}, {color_name} must be a number, got {type(col).__name__}")
                        return
                    
                    if not (0 <= col <= 255):
                        yield ("RGB Range Check", False, f"Frame #{frame_num}, row #{row_num}, pixel #{px_num}, {color_name} must be 0-255, got {col}")
                        return
    
    # All checks passed
    total_pixels = len(frames) * 4 * 55
    yield ("Complete Validation", True, f"All checks passed! {len(frames)} frame(s) × 4 rows × 55 pixels = {total_pixels} valid pixels")


def get_validation_summary(frames):
    """
    Get a summary of validation results.
    
    Args:
        frames: The frames data to validate
        
    Returns:
        dict: Summary containing:
            - valid (bool): Whether all checks passed
            - checks (list): List of all validation check results
            - failed_checks (list): List of failed checks
            - message (str): Overall validation message
    """
    checks = list(validate(frames))
    failed_checks = [check for check in checks if not check[1]]
    all_valid = len(failed_checks) == 0
    
    if all_valid:
        message = "All validation checks passed! ✅"
    else:
        message = f"Validation failed: {failed_checks[0][2]}"
    
    return {
        'valid': all_valid,
        'checks': [
            {
                'name': check[0],
                'passed': check[1],
                'message': check[2]
            }
            for check in checks
        ],
        'failed_checks': [
            {
                'name': check[0],
                'message': check[2]
            }
            for check in failed_checks
        ],
        'message': message
    }