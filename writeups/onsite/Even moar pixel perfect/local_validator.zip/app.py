import os
import subprocess
import sys
import logging
from datetime import datetime
from flask import Flask, request, jsonify, render_template, redirect, url_for
from werkzeug.utils import secure_filename
import json
from utils import get_validation_summary

app = Flask(__name__)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'py'}

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    """Check if the uploaded file has a valid Python extension"""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def execute_python_file(filepath):
    """Execute a Python file and return stdout parsed as JSON (frames)"""
    try:
        logger.info(f"Executing file at path: {filepath}")
        logger.info(f"File exists check: {os.path.exists(filepath)}")
        logger.info(f"Current working directory: {os.getcwd()}")
        
        # Execute the Python file in a subprocess with timeout
        result = subprocess.run(
            [sys.executable, filepath],
            capture_output=True,
            text=True,
            timeout=10,  # 10 second timeout
            cwd='/app'  # Set working directory to app root
        )
        
        # Parse stdout as JSON to get frames
        frames = None
        parse_error = None
        
        if result.stdout.strip():
            try:
                frames = json.loads(result.stdout.strip())
                logger.info(f"Successfully parsed frames from stdout: {len(frames) if isinstance(frames, list) else 'N/A'} items")
            except json.JSONDecodeError as e:
                parse_error = f"Failed to parse stdout as JSON: {str(e)}"
                logger.error(parse_error)
        
        # Validate the frames if we got them
        validation_result = None
        if frames is not None:
            validation_result = get_validation_summary(frames)
            logger.info(f"Validation: {validation_result['message']}")
        
        execution_info = {
            'stdout': result.stdout,
            'stderr': result.stderr,
            'return_code': result.returncode,
            'success': result.returncode == 0 and frames is not None,
            'frames': frames,
            'validation': validation_result,
            'parse_error': parse_error
        }
        
        # Log execution result
        if result.returncode == 0 and frames is not None:
            logger.info(f"Executed {filepath}: SUCCESS")
        else:
            logger.warning(f"Executed {filepath}: FAILED (return_code={result.returncode})")
            if result.stderr.strip():
                logger.error(f"STDERR: {result.stderr.strip()}")
        
        return execution_info
        
    except subprocess.TimeoutExpired:
        error_msg = f"Execution timed out after 10 seconds"
        logger.error(error_msg)
        
        return {
            'stdout': '',
            'stderr': 'Execution timed out after 10 seconds',
            'return_code': -1,
            'success': False,
            'frames': None,
            'validation': None,
            'error': 'timeout'
        }
        
    except Exception as e:
        error_msg = f"Exception during execution: {str(e)}"
        logger.error(error_msg)
        
        return {
            'stdout': '',
            'stderr': f'Execution error: {str(e)}',
            'return_code': -1,
            'success': False,
            'frames': None,
            'validation': None,
            'error': str(e)
        }

@app.route('/')
def hello_world():
    """Redirect to upload_code page or return JSON"""
    # Check if request accepts HTML or wants JSON
    if request.headers.get('Accept') and 'application/json' in request.headers.get('Accept'):
        return jsonify({
            'message': 'Welcome to PixelPerfect CTF. Please use the /upload_code endpoint.',
            'endpoints': {
                '/upload_code': 'Upload Python files endpoint (GET/POST)',
                '/health': 'Health check endpoint'
            }
        })
    else:
        return redirect(url_for('upload_code'))

@app.route('/upload_code', methods=['GET', 'POST'])
def upload_code():
    """Upload Python code files and execute them synchronously"""
    if request.method == 'GET':
        return render_template('upload_code.html')
    
    if request.method == 'POST':
        # Check if file was uploaded
        if 'file' not in request.files:
            return jsonify({'error': 'No file part in the request'}), 400
        
        file = request.files['file']
        
        # Check if file was selected
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Check if file is allowed
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            try:
                # Save the uploaded file
                file.save(filepath)
                logger.info(f"File uploaded: {filename} ({os.path.getsize(filepath)} bytes)")
                
                # Execute the file synchronously
                execution_result = execute_python_file(filepath)
                
                return jsonify({
                    'message': 'File uploaded and executed successfully',
                    'filename': filename,
                    'file_size': os.path.getsize(filepath),
                    'execution_result': execution_result
                }), 200
                
            except Exception as e:
                return jsonify({'error': f'Failed to save or execute file: {str(e)}'}), 500
        else:
            return jsonify({'error': 'Invalid file type. Only .py files are allowed'}), 400

@app.route('/health')
def health_check():
    """Health check endpoint"""
    # Check if request accepts HTML or wants JSON
    if request.headers.get('Accept') and 'application/json' in request.headers.get('Accept'):
        return jsonify({
            'status': 'healthy', 
            'flag': os.getenv('FLAG', 'FLAG_NOT_SET'),
            'timestamp': datetime.now().isoformat()
        })
    else:
        return render_template('health.html', 
                             status='healthy',
                             flag=os.getenv('FLAG', 'FLAG_NOT_SET'),
                             timestamp=datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC'))

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    logger.info(f"Starting PixelPerfect CTF Flask application on port {port}")
    logger.info(f"FLAG: {os.getenv('FLAG', 'FLAG_NOT_SET')}")
    app.run(host='0.0.0.0', port=port, debug=False)