// PixelPerfect CTF - Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize upload form functionality
    initializeUploadForm();
    
    // Initialize file input display
    initializeFileInput();
    
    // Initialize navigation highlighting
    highlightCurrentPage();
});

/**
 * Initialize upload form with AJAX submission
 */
function initializeUploadForm() {
    const uploadForm = document.getElementById('uploadForm');
    if (!uploadForm) return;
    
    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(uploadForm);
        const submitBtn = uploadForm.querySelector('button[type="submit"]');
        const btnText = submitBtn.querySelector('.btn-text');
        const btnLoading = submitBtn.querySelector('.btn-loading');
        const resultDiv = document.getElementById('uploadResult');
        
        // Show loading state
        btnText.style.display = 'none';
        btnLoading.style.display = 'inline';
        submitBtn.disabled = true;
        
        // Clear previous results
        resultDiv.style.display = 'none';
        resultDiv.className = 'upload-result';
        
        // Submit form via AJAX
        fetch('/upload_code', {
            method: 'POST',
            body: formData,
            headers: {
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            // Reset button state
            btnText.style.display = 'inline';
            btnLoading.style.display = 'none';
            submitBtn.disabled = false;
            
            // Show result
            resultDiv.style.display = 'block';
            
            if (data.error) {
                resultDiv.className = 'upload-result error';
                resultDiv.innerHTML = `
                    <strong>Error:</strong> ${escapeHtml(data.error)}
                `;
            } else {
                resultDiv.className = 'upload-result success';
                resultDiv.innerHTML = `
                    <strong>Success!</strong> ${escapeHtml(data.message)}<br>
                    <strong>File:</strong> ${escapeHtml(data.filename)}<br>
                    <strong>Size:</strong> ${data.size} bytes<br>
                    <strong>Path:</strong> ${escapeHtml(data.upload_path)}
                `;
                
                // Reset form
                uploadForm.reset();
                document.querySelector('.file-input-text').textContent = 'Choose file...';
            }
        })
        .catch(error => {
            // Reset button state
            btnText.style.display = 'inline';
            btnLoading.style.display = 'none';
            submitBtn.disabled = false;
            
            // Show error
            resultDiv.style.display = 'block';
            resultDiv.className = 'upload-result error';
            resultDiv.innerHTML = `
                <strong>Network Error:</strong> Failed to upload file. Please try again.
            `;
            
            console.error('Upload error:', error);
        });
    });
}

/**
 * Initialize file input display functionality
 */
function initializeFileInput() {
    const fileInput = document.getElementById('file');
    const fileInputText = document.querySelector('.file-input-text');
    
    if (!fileInput || !fileInputText) return;
    
    fileInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            fileInputText.textContent = file.name;
            
            // Validate file type
            if (!file.name.toLowerCase().endsWith('.py')) {
                fileInputText.style.color = '#e74c3c';
                fileInputText.textContent = `${file.name} (Invalid: Only .py files allowed)`;
            } else {
                fileInputText.style.color = '#27ae60';
            }
        } else {
            fileInputText.textContent = 'Choose file...';
            fileInputText.style.color = '';
        }
    });
}

/**
 * Highlight current page in navigation
 */
function highlightCurrentPage() {
    const navLinks = document.querySelectorAll('.nav-menu a');
    const currentPath = window.location.pathname;
    
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
        }
    });
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Show notification (can be used for future features)
 */
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem;
        border-radius: 4px;
        color: white;
        z-index: 1000;
        max-width: 300px;
        animation: slideIn 0.3s ease-out;
    `;
    
    // Set background color based on type
    switch (type) {
        case 'success':
            notification.style.backgroundColor = '#27ae60';
            break;
        case 'error':
            notification.style.backgroundColor = '#e74c3c';
            break;
        case 'warning':
            notification.style.backgroundColor = '#f39c12';
            break;
        default:
            notification.style.backgroundColor = '#3498db';
    }
    
    notification.textContent = message;
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Add slide-in animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);