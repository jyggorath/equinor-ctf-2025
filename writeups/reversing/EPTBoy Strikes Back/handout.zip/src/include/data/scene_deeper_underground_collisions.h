#ifndef SCENE_DEEPER_UNDERGROUND_COLLISIONS_H
#define SCENE_DEEPER_UNDERGROUND_COLLISIONS_H

// Scene: caves/Deeper Underground
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_deeper_underground_collisions)
extern const unsigned char scene_deeper_underground_collisions[];

#endif
