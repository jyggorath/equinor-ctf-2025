#ifndef FONT_GBS_VARIABLE_WIDTH_H
#define FONT_GBS_VARIABLE_WIDTH_H

// Font gbs-var.png

#include "gbs_types.h"

BANKREF_EXTERN(font_gbs_variable_width)
extern const unsigned char font_gbs_variable_width[];

#endif
