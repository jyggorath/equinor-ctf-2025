#ifndef ACTOR_CHEST_INTERACT_H
#define ACTOR_CHEST_INTERACT_H

// Script actor_chest_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_chest_interact)
extern const unsigned char actor_chest_interact[];

#endif
