#ifndef BG_BLACK_TILEMAP_ATTR_H
#define BG_BLACK_TILEMAP_ATTR_H

// Tilemap Attr bg_black_tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_black_tilemap_attr)
extern const unsigned char bg_black_tilemap_attr[];

#endif
