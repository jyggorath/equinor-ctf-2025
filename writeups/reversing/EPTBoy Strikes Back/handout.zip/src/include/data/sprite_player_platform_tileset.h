#ifndef SPRITE_PLAYER_PLATFORM_TILESET_H
#define SPRITE_PLAYER_PLATFORM_TILESET_H

// Tileset: sprite_player_platform_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_player_platform_tileset)
extern const struct tileset_t sprite_player_platform_tileset;

#endif
