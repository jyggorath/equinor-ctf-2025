#ifndef SPRITE_ENEMY_SHIP_H
#define SPRITE_ENEMY_SHIP_H

// SpriteSheet: enemy_ship

#include "gbs_types.h"

BANKREF_EXTERN(sprite_enemy_ship)
extern const struct spritesheet_t sprite_enemy_ship;

#endif
