#ifndef SCENE_TOP_HOUSE_H
#define SCENE_TOP_HOUSE_H

// Scene: town/Oljemuseum

#include "gbs_types.h"

BANKREF_EXTERN(scene_top_house)
extern const struct scene_t scene_top_house;

#endif
