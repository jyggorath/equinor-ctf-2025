#ifndef ACTOR_31_INTERACT_H
#define ACTOR_31_INTERACT_H

// Script actor_31_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_31_interact)
extern const unsigned char actor_31_interact[];

#endif
