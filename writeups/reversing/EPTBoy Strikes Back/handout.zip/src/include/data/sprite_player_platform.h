#ifndef SPRITE_PLAYER_PLATFORM_H
#define SPRITE_PLAYER_PLATFORM_H

// SpriteSheet: player_platform

#include "gbs_types.h"

BANKREF_EXTERN(sprite_player_platform)
extern const struct spritesheet_t sprite_player_platform;

#endif
