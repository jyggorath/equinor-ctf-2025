#ifndef SCENE_LOGO_COLLISIONS_H
#define SCENE_LOGO_COLLISIONS_H

// Scene: ui/Logo
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_logo_collisions)
extern const unsigned char scene_logo_collisions[];

#endif
