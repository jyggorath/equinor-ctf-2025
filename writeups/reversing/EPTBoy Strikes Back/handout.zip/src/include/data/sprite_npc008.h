#ifndef SPRITE_NPC008_H
#define SPRITE_NPC008_H

// SpriteSheet: npc008

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc008)
extern const struct spritesheet_t sprite_npc008;

#endif
