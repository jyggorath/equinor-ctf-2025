#ifndef SCENE_UNDERGROUND_H
#define SCENE_UNDERGROUND_H

// Scene: caves/Underground

#include "gbs_types.h"

BANKREF_EXTERN(scene_underground)
extern const struct scene_t scene_underground;

#endif
