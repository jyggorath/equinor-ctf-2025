#ifndef ACTOR_39_INTERACT_H
#define ACTOR_39_INTERACT_H

// Script actor_39_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_39_interact)
extern const unsigned char actor_39_interact[];

#endif
