#ifndef SPRITE_ICE_H
#define SPRITE_ICE_H

// SpriteSheet: ice

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ice)
extern const struct spritesheet_t sprite_ice;

#endif
