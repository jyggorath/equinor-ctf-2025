#ifndef SPRITE_CHEST_H
#define SPRITE_CHEST_H

// SpriteSheet: chest

#include "gbs_types.h"

BANKREF_EXTERN(sprite_chest)
extern const struct spritesheet_t sprite_chest;

#endif
