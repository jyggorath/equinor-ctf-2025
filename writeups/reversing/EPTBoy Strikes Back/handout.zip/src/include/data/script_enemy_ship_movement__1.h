#ifndef SCRIPT_ENEMY_SHIP_MOVEMENT__1_H
#define SCRIPT_ENEMY_SHIP_MOVEMENT__1_H

// Script script_enemy_ship_movement__1

#include "gbs_types.h"

BANKREF_EXTERN(script_enemy_ship_movement__1)
extern const unsigned char script_enemy_ship_movement__1[];

#endif
