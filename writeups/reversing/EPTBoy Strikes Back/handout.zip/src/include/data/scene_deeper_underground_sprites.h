#ifndef SCENE_DEEPER_UNDERGROUND_SPRITES_H
#define SCENE_DEEPER_UNDERGROUND_SPRITES_H

// Scene: caves/Deeper Underground
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_deeper_underground_sprites)
extern const far_ptr_t scene_deeper_underground_sprites[];

#endif
