#ifndef BG_HOUSE_TILEMAP_H
#define BG_HOUSE_TILEMAP_H

// Tilemap bg_house_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_house_tilemap)
extern const unsigned char bg_house_tilemap[];

#endif
