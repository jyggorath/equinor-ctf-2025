#ifndef SCENE_SAMPLE_TOWN_ACTORS_H
#define SCENE_SAMPLE_TOWN_ACTORS_H

// Scene: town/Lykkeland
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_sample_town_actors)
extern const struct actor_t scene_sample_town_actors[];

#endif
