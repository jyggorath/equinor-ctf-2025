#ifndef SCENE_TOP_HOUSE_TRIGGERS_H
#define SCENE_TOP_HOUSE_TRIGGERS_H

// Scene: town/Oljemuseum
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_top_house_triggers)
extern const struct trigger_t scene_top_house_triggers[];

#endif
