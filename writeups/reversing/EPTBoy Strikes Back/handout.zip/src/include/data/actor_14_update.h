#ifndef ACTOR_14_UPDATE_H
#define ACTOR_14_UPDATE_H

// Script actor_14_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_14_update)
extern const unsigned char actor_14_update[];

#endif
