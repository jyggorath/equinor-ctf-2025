#ifndef SCENE_SPACE_BATTLE_ACTORS_H
#define SCENE_SPACE_BATTLE_ACTORS_H

// Scene: space/Space Battle
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_space_battle_actors)
extern const struct actor_t scene_space_battle_actors[];

#endif
