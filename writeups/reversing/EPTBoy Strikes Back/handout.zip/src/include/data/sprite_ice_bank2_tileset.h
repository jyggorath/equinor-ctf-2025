#ifndef SPRITE_ICE_BANK2_TILESET_H
#define SPRITE_ICE_BANK2_TILESET_H

// Tileset: sprite_ice_bank2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ice_bank2_tileset)
extern const struct tileset_t sprite_ice_bank2_tileset;

#endif
