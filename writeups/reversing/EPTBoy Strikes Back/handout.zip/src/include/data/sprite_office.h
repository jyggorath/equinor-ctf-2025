#ifndef SPRITE_OFFICE_H
#define SPRITE_OFFICE_H

// SpriteSheet: office

#include "gbs_types.h"

BANKREF_EXTERN(sprite_office)
extern const struct spritesheet_t sprite_office;

#endif
