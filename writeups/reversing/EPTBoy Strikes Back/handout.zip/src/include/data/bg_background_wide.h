#ifndef BG_BACKGROUND_WIDE_H
#define BG_BACKGROUND_WIDE_H

// Background: background_wide

#include "gbs_types.h"

BANKREF_EXTERN(bg_background_wide)
extern const struct background_t bg_background_wide;

#endif
