#ifndef BG_SAMPLE_TOWN_TILEMAP_ATTR_H
#define BG_SAMPLE_TOWN_TILEMAP_ATTR_H

// Tilemap Attr bg_sample_town_tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_sample_town_tilemap_attr)
extern const unsigned char bg_sample_town_tilemap_attr[];

#endif
