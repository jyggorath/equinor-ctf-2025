#ifndef ACTOR_9_UPDATE_H
#define ACTOR_9_UPDATE_H

// Script actor_9_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_9_update)
extern const unsigned char actor_9_update[];

#endif
