#ifndef SCENE_CAVE_ACTORS_H
#define SCENE_CAVE_ACTORS_H

// Scene: caves/Cave
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_cave_actors)
extern const struct actor_t scene_cave_actors[];

#endif
