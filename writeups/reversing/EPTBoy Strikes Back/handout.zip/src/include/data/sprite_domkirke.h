#ifndef SPRITE_DOMKIRKE_H
#define SPRITE_DOMKIRKE_H

// SpriteSheet: domkirke

#include "gbs_types.h"

BANKREF_EXTERN(sprite_domkirke)
extern const struct spritesheet_t sprite_domkirke;

#endif
