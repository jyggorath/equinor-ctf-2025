#ifndef ACTOR_8_UPDATE_H
#define ACTOR_8_UPDATE_H

// Script actor_8_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_8_update)
extern const unsigned char actor_8_update[];

#endif
