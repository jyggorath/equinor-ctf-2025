#ifndef SCENE_UNDERGROUND_TRIGGERS_H
#define SCENE_UNDERGROUND_TRIGGERS_H

// Scene: caves/Underground
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_underground_triggers)
extern const struct trigger_t scene_underground_triggers[];

#endif
