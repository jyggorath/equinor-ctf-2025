#ifndef ACTOR_4_INTERACT_H
#define ACTOR_4_INTERACT_H

// Script actor_4_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_4_interact)
extern const unsigned char actor_4_interact[];

#endif
