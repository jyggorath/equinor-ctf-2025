#ifndef ACTOR_10_UPDATE_H
#define ACTOR_10_UPDATE_H

// Script actor_10_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_10_update)
extern const unsigned char actor_10_update[];

#endif
