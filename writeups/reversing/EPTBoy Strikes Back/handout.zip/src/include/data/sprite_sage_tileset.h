#ifndef SPRITE_SAGE_TILESET_H
#define SPRITE_SAGE_TILESET_H

// Tileset: sprite_sage_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_sage_tileset)
extern const struct tileset_t sprite_sage_tileset;

#endif
