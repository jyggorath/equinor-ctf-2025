#ifndef BG_EPT_H
#define BG_EPT_H

// Background: gameboy

#include "gbs_types.h"

BANKREF_EXTERN(bg_ept)
extern const struct background_t bg_ept;

#endif
