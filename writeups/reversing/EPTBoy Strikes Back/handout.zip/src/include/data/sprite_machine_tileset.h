#ifndef SPRITE_MACHINE_TILESET_H
#define SPRITE_MACHINE_TILESET_H

// Tileset: sprite_machine_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_machine_tileset)
extern const struct tileset_t sprite_machine_tileset;

#endif
