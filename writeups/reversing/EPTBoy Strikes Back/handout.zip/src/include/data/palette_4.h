#ifndef PALETTE_4_H
#define PALETTE_4_H

// Palette: 4

#include "gbs_types.h"

BANKREF_EXTERN(palette_4)
extern const struct palette_t palette_4;

#endif
