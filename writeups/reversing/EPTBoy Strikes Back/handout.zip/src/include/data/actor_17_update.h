#ifndef ACTOR_17_UPDATE_H
#define ACTOR_17_UPDATE_H

// Script actor_17_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_17_update)
extern const unsigned char actor_17_update[];

#endif
