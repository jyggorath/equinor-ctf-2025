#ifndef SCRIPT_ENEMY_SHIP_DESTROY_H
#define SCRIPT_ENEMY_SHIP_DESTROY_H

// Script script_enemy_ship_destroy

#include "gbs_types.h"

BANKREF_EXTERN(script_enemy_ship_destroy)
extern const unsigned char script_enemy_ship_destroy[];

#endif
