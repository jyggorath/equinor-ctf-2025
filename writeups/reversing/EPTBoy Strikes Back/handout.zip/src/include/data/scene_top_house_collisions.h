#ifndef SCENE_TOP_HOUSE_COLLISIONS_H
#define SCENE_TOP_HOUSE_COLLISIONS_H

// Scene: town/Oljemuseum
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_top_house_collisions)
extern const unsigned char scene_top_house_collisions[];

#endif
