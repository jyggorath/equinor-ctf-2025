#ifndef TRIGGER_14_INTERACT_H
#define TRIGGER_14_INTERACT_H

// Script trigger_14_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_14_interact)
extern const unsigned char trigger_14_interact[];

#endif
