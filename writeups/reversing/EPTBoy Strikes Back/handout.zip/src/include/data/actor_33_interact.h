#ifndef ACTOR_33_INTERACT_H
#define ACTOR_33_INTERACT_H

// Script actor_33_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_33_interact)
extern const unsigned char actor_33_interact[];

#endif
