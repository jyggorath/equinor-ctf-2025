#ifndef ACTOR_12_INTERACT_H
#define ACTOR_12_INTERACT_H

// Script actor_12_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_12_interact)
extern const unsigned char actor_12_interact[];

#endif
