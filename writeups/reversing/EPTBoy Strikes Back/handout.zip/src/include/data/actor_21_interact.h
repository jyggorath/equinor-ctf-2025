#ifndef ACTOR_21_INTERACT_H
#define ACTOR_21_INTERACT_H

// Script actor_21_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_21_interact)
extern const unsigned char actor_21_interact[];

#endif
