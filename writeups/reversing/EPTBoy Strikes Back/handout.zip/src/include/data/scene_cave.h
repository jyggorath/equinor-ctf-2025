#ifndef SCENE_CAVE_H
#define SCENE_CAVE_H

// Scene: caves/Cave

#include "gbs_types.h"

BANKREF_EXTERN(scene_cave)
extern const struct scene_t scene_cave;

#endif
