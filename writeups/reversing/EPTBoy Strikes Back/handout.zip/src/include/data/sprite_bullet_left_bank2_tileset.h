#ifndef SPRITE_BULLET_LEFT_BANK2_TILESET_H
#define SPRITE_BULLET_LEFT_BANK2_TILESET_H

// Tileset: sprite_bullet_left_bank2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bullet_left_bank2_tileset)
extern const struct tileset_t sprite_bullet_left_bank2_tileset;

#endif
