#ifndef BG_BLACK_TILEMAP_H
#define BG_BLACK_TILEMAP_H

// Tilemap bg_black_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_black_tilemap)
extern const unsigned char bg_black_tilemap[];

#endif
