#ifndef SPRITE_PLAYER_SHIP_TILESET_H
#define SPRITE_PLAYER_SHIP_TILESET_H

// Tileset: sprite_player_ship_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_player_ship_tileset)
extern const struct tileset_t sprite_player_ship_tileset;

#endif
