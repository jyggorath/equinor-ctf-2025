#ifndef SCENE_18_COLLISIONS_H
#define SCENE_18_COLLISIONS_H

// Scene: Game Over
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_18_collisions)
extern const unsigned char scene_18_collisions[];

#endif
