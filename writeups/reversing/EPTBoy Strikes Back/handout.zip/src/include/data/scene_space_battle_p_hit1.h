#ifndef SCENE_SPACE_BATTLE_P_HIT1_H
#define SCENE_SPACE_BATTLE_P_HIT1_H

// Script scene_space_battle_p_hit1

#include "gbs_types.h"

BANKREF_EXTERN(scene_space_battle_p_hit1)
extern const unsigned char scene_space_battle_p_hit1[];

#endif
