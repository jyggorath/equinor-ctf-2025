#ifndef ACTOR_ROCK_2_INTERACT_H
#define ACTOR_ROCK_2_INTERACT_H

// Script actor_rock_2_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_rock_2_interact)
extern const unsigned char actor_rock_2_interact[];

#endif
