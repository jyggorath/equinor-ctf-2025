#ifndef ACTOR_13_UPDATE_H
#define ACTOR_13_UPDATE_H

// Script actor_13_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_13_update)
extern const unsigned char actor_13_update[];

#endif
