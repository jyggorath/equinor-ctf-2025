#ifndef SPRITE_BARREL_MINE_H
#define SPRITE_BARREL_MINE_H

// SpriteSheet: barrel_mine

#include "gbs_types.h"

BANKREF_EXTERN(sprite_barrel_mine)
extern const struct spritesheet_t sprite_barrel_mine;

#endif
