#ifndef SPRITE_CHEST_BANK2_TILESET_H
#define SPRITE_CHEST_BANK2_TILESET_H

// Tileset: sprite_chest_bank2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_chest_bank2_tileset)
extern const struct tileset_t sprite_chest_bank2_tileset;

#endif
