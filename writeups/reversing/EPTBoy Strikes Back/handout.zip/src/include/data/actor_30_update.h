#ifndef ACTOR_30_UPDATE_H
#define ACTOR_30_UPDATE_H

// Script actor_30_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_30_update)
extern const unsigned char actor_30_update[];

#endif
