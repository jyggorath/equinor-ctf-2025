#ifndef SCENE_UNDERGROUND_ACTORS_H
#define SCENE_UNDERGROUND_ACTORS_H

// Scene: caves/Underground
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_underground_actors)
extern const struct actor_t scene_underground_actors[];

#endif
