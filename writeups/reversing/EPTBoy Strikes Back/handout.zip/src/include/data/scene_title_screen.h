#ifndef SCENE_TITLE_SCREEN_H
#define SCENE_TITLE_SCREEN_H

// Scene: ui/Title Screen

#include "gbs_types.h"

BANKREF_EXTERN(scene_title_screen)
extern const struct scene_t scene_title_screen;

#endif
