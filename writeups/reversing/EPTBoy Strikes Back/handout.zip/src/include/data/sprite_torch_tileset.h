#ifndef SPRITE_TORCH_TILESET_H
#define SPRITE_TORCH_TILESET_H

// Tileset: sprite_torch_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_torch_tileset)
extern const struct tileset_t sprite_torch_tileset;

#endif
