#ifndef STATES_DEFINES_H
#define STATES_DEFINES_H

#define INPUT_PLATFORM_JUMP              INPUT_A
#define INPUT_PLATFORM_RUN               INPUT_B
#define INPUT_PLATFORM_INTERACT          INPUT_A
#define INPUT_TOPDOWN_INTERACT           INPUT_A

#endif
