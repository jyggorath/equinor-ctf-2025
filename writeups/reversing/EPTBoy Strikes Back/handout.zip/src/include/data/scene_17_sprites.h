#ifndef SCENE_17_SPRITES_H
#define SCENE_17_SPRITES_H

// Scene: town/EPT Office
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_17_sprites)
extern const far_ptr_t scene_17_sprites[];

#endif
