#ifndef BG_CAVE_TILEMAP_ATTR_H
#define BG_CAVE_TILEMAP_ATTR_H

// Tilemap Attr bg_cave_tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave_tilemap_attr)
extern const unsigned char bg_cave_tilemap_attr[];

#endif
