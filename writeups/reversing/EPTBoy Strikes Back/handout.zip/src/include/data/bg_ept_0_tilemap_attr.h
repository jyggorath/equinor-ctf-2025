#ifndef BG_EPT_0_TILEMAP_ATTR_H
#define BG_EPT_0_TILEMAP_ATTR_H

// Tilemap Attr bg_ept_0_tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_ept_0_tilemap_attr)
extern const unsigned char bg_ept_0_tilemap_attr[];

#endif
