#ifndef SPRITE_FLAPPY_TILESET_H
#define SPRITE_FLAPPY_TILESET_H

// Tileset: sprite_flappy_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_flappy_tileset)
extern const struct tileset_t sprite_flappy_tileset;

#endif
