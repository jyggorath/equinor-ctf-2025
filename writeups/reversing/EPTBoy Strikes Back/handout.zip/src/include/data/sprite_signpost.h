#ifndef SPRITE_SIGNPOST_H
#define SPRITE_SIGNPOST_H

// SpriteSheet: signpost

#include "gbs_types.h"

BANKREF_EXTERN(sprite_signpost)
extern const struct spritesheet_t sprite_signpost;

#endif
