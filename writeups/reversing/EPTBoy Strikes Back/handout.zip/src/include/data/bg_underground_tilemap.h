#ifndef BG_UNDERGROUND_TILEMAP_H
#define BG_UNDERGROUND_TILEMAP_H

// Tilemap bg_underground_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_underground_tilemap)
extern const unsigned char bg_underground_tilemap[];

#endif
