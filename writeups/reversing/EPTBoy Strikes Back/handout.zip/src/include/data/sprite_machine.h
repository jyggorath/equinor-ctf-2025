#ifndef SPRITE_MACHINE_H
#define SPRITE_MACHINE_H

// SpriteSheet: machine

#include "gbs_types.h"

BANKREF_EXTERN(sprite_machine)
extern const struct spritesheet_t sprite_machine;

#endif
