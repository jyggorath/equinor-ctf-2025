#ifndef SCENE_SPACE_BATTLE_COLLISIONS_H
#define SCENE_SPACE_BATTLE_COLLISIONS_H

// Scene: space/Space Battle
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_space_battle_collisions)
extern const unsigned char scene_space_battle_collisions[];

#endif
