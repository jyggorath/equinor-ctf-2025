#ifndef ACTOR_32_INTERACT_H
#define ACTOR_32_INTERACT_H

// Script actor_32_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_32_interact)
extern const unsigned char actor_32_interact[];

#endif
