#ifndef SPRITE_ICE_TILESET_H
#define SPRITE_ICE_TILESET_H

// Tileset: sprite_ice_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_ice_tileset)
extern const struct tileset_t sprite_ice_tileset;

#endif
