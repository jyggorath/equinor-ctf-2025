#ifndef SCENE_DEEPER_UNDERGROUND_H
#define SCENE_DEEPER_UNDERGROUND_H

// Scene: caves/Deeper Underground

#include "gbs_types.h"

BANKREF_EXTERN(scene_deeper_underground)
extern const struct scene_t scene_deeper_underground;

#endif
