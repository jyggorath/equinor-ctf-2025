#ifndef ACTOR_27_UPDATE_H
#define ACTOR_27_UPDATE_H

// Script actor_27_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_27_update)
extern const unsigned char actor_27_update[];

#endif
