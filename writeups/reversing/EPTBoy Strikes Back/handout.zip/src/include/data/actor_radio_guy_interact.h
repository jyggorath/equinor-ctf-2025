#ifndef ACTOR_RADIO_GUY_INTERACT_H
#define ACTOR_RADIO_GUY_INTERACT_H

// Script actor_radio_guy_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_radio_guy_interact)
extern const unsigned char actor_radio_guy_interact[];

#endif
