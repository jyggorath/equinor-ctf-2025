#ifndef ACTOR_14_INTERACT_H
#define ACTOR_14_INTERACT_H

// Script actor_14_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_14_interact)
extern const unsigned char actor_14_interact[];

#endif
