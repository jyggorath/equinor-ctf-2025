#ifndef SPRITE_NPC002_TILESET_H
#define SPRITE_NPC002_TILESET_H

// Tileset: sprite_npc002_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc002_tileset)
extern const struct tileset_t sprite_npc002_tileset;

#endif
