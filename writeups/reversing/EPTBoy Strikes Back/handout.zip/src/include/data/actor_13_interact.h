#ifndef ACTOR_13_INTERACT_H
#define ACTOR_13_INTERACT_H

// Script actor_13_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_13_interact)
extern const unsigned char actor_13_interact[];

#endif
