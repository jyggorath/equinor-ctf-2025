#ifndef __sound_gbstudio_sfx_sav_INCLUDE__
#define __sound_gbstudio_sfx_sav_INCLUDE__

#include <gbdk/platform.h>
#include <stdint.h>

#define MUTE_MASK_sound_gbstudio_sfx_sav_00 0b00000010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_00)
      extern const uint8_t sound_gbstudio_sfx_sav_00[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_00;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_01 0b00000010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_01)
      extern const uint8_t sound_gbstudio_sfx_sav_01[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_01;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_02 0b00000010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_02)
      extern const uint8_t sound_gbstudio_sfx_sav_02[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_02;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_03 0b00000010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_03)
      extern const uint8_t sound_gbstudio_sfx_sav_03[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_03;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_04 0b00000010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_04)
      extern const uint8_t sound_gbstudio_sfx_sav_04[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_04;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_05 0b00000010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_05)
      extern const uint8_t sound_gbstudio_sfx_sav_05[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_05;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_06 0b00000010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_06)
      extern const uint8_t sound_gbstudio_sfx_sav_06[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_06;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_07 0b00001000
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_07)
      extern const uint8_t sound_gbstudio_sfx_sav_07[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_07;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_08 0b00001000
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_08)
      extern const uint8_t sound_gbstudio_sfx_sav_08[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_08;

      #define MUTE_MASK_sound_gbstudio_sfx_sav_09 0b00001010
      BANKREF_EXTERN(sound_gbstudio_sfx_sav_09)
      extern const uint8_t sound_gbstudio_sfx_sav_09[];
      extern void __mute_mask_sound_gbstudio_sfx_sav_09;

      

#endif
    