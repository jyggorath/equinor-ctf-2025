#ifndef BG_HIDDEN_CAVE_TILEMAP_ATTR_H
#define BG_HIDDEN_CAVE_TILEMAP_ATTR_H

// Tilemap Attr bg_hidden_cave_tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_hidden_cave_tilemap_attr)
extern const unsigned char bg_hidden_cave_tilemap_attr[];

#endif
