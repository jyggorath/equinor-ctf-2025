#ifndef SCRIPT_INPUT_6_H
#define SCRIPT_INPUT_6_H

// Script script_input_6

#include "gbs_types.h"

BANKREF_EXTERN(script_input_6)
extern const unsigned char script_input_6[];

#endif
