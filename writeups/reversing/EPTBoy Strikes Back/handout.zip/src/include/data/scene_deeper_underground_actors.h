#ifndef SCENE_DEEPER_UNDERGROUND_ACTORS_H
#define SCENE_DEEPER_UNDERGROUND_ACTORS_H

// Scene: caves/Deeper Underground
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_deeper_underground_actors)
extern const struct actor_t scene_deeper_underground_actors[];

#endif
