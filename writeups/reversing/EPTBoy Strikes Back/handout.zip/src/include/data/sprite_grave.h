#ifndef SPRITE_GRAVE_H
#define SPRITE_GRAVE_H

// SpriteSheet: grave

#include "gbs_types.h"

BANKREF_EXTERN(sprite_grave)
extern const struct spritesheet_t sprite_grave;

#endif
