#ifndef SCRIPT_ENEMY_SHIP_MOVEMENT__2_H
#define SCRIPT_ENEMY_SHIP_MOVEMENT__2_H

// Script script_enemy_ship_movement__2

#include "gbs_types.h"

BANKREF_EXTERN(script_enemy_ship_movement__2)
extern const unsigned char script_enemy_ship_movement__2[];

#endif
