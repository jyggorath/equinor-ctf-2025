#ifndef ACTOR_SAGE_INTERACT_H
#define ACTOR_SAGE_INTERACT_H

// Script actor_sage_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_sage_interact)
extern const unsigned char actor_sage_interact[];

#endif
