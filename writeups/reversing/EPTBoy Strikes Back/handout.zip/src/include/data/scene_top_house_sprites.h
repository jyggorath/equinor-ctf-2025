#ifndef SCENE_TOP_HOUSE_SPRITES_H
#define SCENE_TOP_HOUSE_SPRITES_H

// Scene: town/Oljemuseum
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_top_house_sprites)
extern const far_ptr_t scene_top_house_sprites[];

#endif
