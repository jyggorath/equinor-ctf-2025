#ifndef SCRIPT_INIT_WEAPONS_H
#define SCRIPT_INIT_WEAPONS_H

// Script script_init_weapons

#include "gbs_types.h"

BANKREF_EXTERN(script_init_weapons)
extern const unsigned char script_init_weapons[];

#endif
