#ifndef BG_SAMPLE_TOWN_TILEMAP_H
#define BG_SAMPLE_TOWN_TILEMAP_H

// Tilemap bg_sample_town_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_sample_town_tilemap)
extern const unsigned char bg_sample_town_tilemap[];

#endif
