#ifndef SCENE_17_H
#define SCENE_17_H

// Scene: town/EPT Office

#include "gbs_types.h"

BANKREF_EXTERN(scene_17)
extern const struct scene_t scene_17;

#endif
