#ifndef SPRITE_ROCK_TILESET_H
#define SPRITE_ROCK_TILESET_H

// Tileset: sprite_rock_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_rock_tileset)
extern const struct tileset_t sprite_rock_tileset;

#endif
