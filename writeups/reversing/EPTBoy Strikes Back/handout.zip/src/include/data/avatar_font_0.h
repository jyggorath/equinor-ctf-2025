#ifndef AVATAR_FONT_0_H
#define AVATAR_FONT_0_H

// Avatar Font 0

#include "gbs_types.h"

BANKREF_EXTERN(avatar_font_0)
extern const unsigned char avatar_font_0[];

#endif
