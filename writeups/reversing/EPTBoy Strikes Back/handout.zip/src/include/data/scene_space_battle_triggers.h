#ifndef SCENE_SPACE_BATTLE_TRIGGERS_H
#define SCENE_SPACE_BATTLE_TRIGGERS_H

// Scene: space/Space Battle
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_space_battle_triggers)
extern const struct trigger_t scene_space_battle_triggers[];

#endif
