#ifndef SCENE_TITLE_SCREEN_INIT_H
#define SCENE_TITLE_SCREEN_INIT_H

// Script scene_title_screen_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_title_screen_init)
extern const unsigned char scene_title_screen_init[];

#endif
