#ifndef SCRIPT_INPUT_4_H
#define SCRIPT_INPUT_4_H

// Script script_input_4

#include "gbs_types.h"

BANKREF_EXTERN(script_input_4)
extern const unsigned char script_input_4[];

#endif
