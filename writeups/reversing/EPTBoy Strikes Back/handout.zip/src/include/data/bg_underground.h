#ifndef BG_UNDERGROUND_H
#define BG_UNDERGROUND_H

// Background: underground

#include "gbs_types.h"

BANKREF_EXTERN(bg_underground)
extern const struct background_t bg_underground;

#endif
