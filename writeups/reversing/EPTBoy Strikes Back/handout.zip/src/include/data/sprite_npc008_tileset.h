#ifndef SPRITE_NPC008_TILESET_H
#define SPRITE_NPC008_TILESET_H

// Tileset: sprite_npc008_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc008_tileset)
extern const struct tileset_t sprite_npc008_tileset;

#endif
