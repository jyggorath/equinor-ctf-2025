#ifndef ACTOR_5_INTERACT_H
#define ACTOR_5_INTERACT_H

// Script actor_5_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_5_interact)
extern const unsigned char actor_5_interact[];

#endif
