#ifndef ACTOR_27_INTERACT_H
#define ACTOR_27_INTERACT_H

// Script actor_27_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_27_interact)
extern const unsigned char actor_27_interact[];

#endif
