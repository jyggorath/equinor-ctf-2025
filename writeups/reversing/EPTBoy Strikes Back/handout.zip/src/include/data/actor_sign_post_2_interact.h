#ifndef ACTOR_SIGN_POST_2_INTERACT_H
#define ACTOR_SIGN_POST_2_INTERACT_H

// Script actor_sign_post_2_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_sign_post_2_interact)
extern const unsigned char actor_sign_post_2_interact[];

#endif
