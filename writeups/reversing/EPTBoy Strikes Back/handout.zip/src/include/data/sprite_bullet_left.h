#ifndef SPRITE_BULLET_LEFT_H
#define SPRITE_BULLET_LEFT_H

// SpriteSheet: bullet_left

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bullet_left)
extern const struct spritesheet_t sprite_bullet_left;

#endif
