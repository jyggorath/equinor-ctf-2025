#ifndef ACTOR_23_INTERACT_H
#define ACTOR_23_INTERACT_H

// Script actor_23_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_23_interact)
extern const unsigned char actor_23_interact[];

#endif
