#ifndef BG_UNDERGROUND_TILEMAP_ATTR_H
#define BG_UNDERGROUND_TILEMAP_ATTR_H

// Tilemap Attr bg_underground_tilemap_attr

#include "gbs_types.h"

BANKREF_EXTERN(bg_underground_tilemap_attr)
extern const unsigned char bg_underground_tilemap_attr[];

#endif
