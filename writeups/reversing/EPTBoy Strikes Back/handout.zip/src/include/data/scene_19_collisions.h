#ifndef SCENE_19_COLLISIONS_H
#define SCENE_19_COLLISIONS_H

// Scene: Win
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_19_collisions)
extern const unsigned char scene_19_collisions[];

#endif
