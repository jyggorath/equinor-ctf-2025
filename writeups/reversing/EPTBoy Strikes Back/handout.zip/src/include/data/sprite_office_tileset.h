#ifndef SPRITE_OFFICE_TILESET_H
#define SPRITE_OFFICE_TILESET_H

// Tileset: sprite_office_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_office_tileset)
extern const struct tileset_t sprite_office_tileset;

#endif
