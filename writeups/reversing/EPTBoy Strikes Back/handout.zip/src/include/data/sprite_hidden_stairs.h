#ifndef SPRITE_HIDDEN_STAIRS_H
#define SPRITE_HIDDEN_STAIRS_H

// SpriteSheet: hidden_stairs

#include "gbs_types.h"

BANKREF_EXTERN(sprite_hidden_stairs)
extern const struct spritesheet_t sprite_hidden_stairs;

#endif
