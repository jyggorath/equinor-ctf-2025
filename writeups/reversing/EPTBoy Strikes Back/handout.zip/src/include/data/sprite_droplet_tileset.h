#ifndef SPRITE_DROPLET_TILESET_H
#define SPRITE_DROPLET_TILESET_H

// Tileset: sprite_droplet_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_droplet_tileset)
extern const struct tileset_t sprite_droplet_tileset;

#endif
