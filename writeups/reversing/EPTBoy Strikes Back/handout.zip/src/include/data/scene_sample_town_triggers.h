#ifndef SCENE_SAMPLE_TOWN_TRIGGERS_H
#define SCENE_SAMPLE_TOWN_TRIGGERS_H

// Scene: town/Lykkeland
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_sample_town_triggers)
extern const struct trigger_t scene_sample_town_triggers[];

#endif
