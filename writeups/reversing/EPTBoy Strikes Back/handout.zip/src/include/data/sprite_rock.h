#ifndef SPRITE_ROCK_H
#define SPRITE_ROCK_H

// SpriteSheet: rock

#include "gbs_types.h"

BANKREF_EXTERN(sprite_rock)
extern const struct spritesheet_t sprite_rock;

#endif
