#ifndef SPRITE_SIGNPOST_TILESET_H
#define SPRITE_SIGNPOST_TILESET_H

// Tileset: sprite_signpost_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_signpost_tileset)
extern const struct tileset_t sprite_signpost_tileset;

#endif
