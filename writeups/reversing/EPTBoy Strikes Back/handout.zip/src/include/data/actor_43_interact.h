#ifndef ACTOR_43_INTERACT_H
#define ACTOR_43_INTERACT_H

// Script actor_43_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_43_interact)
extern const unsigned char actor_43_interact[];

#endif
