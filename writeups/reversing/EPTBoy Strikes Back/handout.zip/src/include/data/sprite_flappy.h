#ifndef SPRITE_FLAPPY_H
#define SPRITE_FLAPPY_H

// SpriteSheet: flappy

#include "gbs_types.h"

BANKREF_EXTERN(sprite_flappy)
extern const struct spritesheet_t sprite_flappy;

#endif
