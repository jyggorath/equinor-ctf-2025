#ifndef ACTOR_29_UPDATE_H
#define ACTOR_29_UPDATE_H

// Script actor_29_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_29_update)
extern const unsigned char actor_29_update[];

#endif
