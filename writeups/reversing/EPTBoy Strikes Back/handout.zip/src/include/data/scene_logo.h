#ifndef SCENE_LOGO_H
#define SCENE_LOGO_H

// Scene: ui/Logo

#include "gbs_types.h"

BANKREF_EXTERN(scene_logo)
extern const struct scene_t scene_logo;

#endif
