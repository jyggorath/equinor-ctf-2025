#ifndef SCRIPT_ENEMY_SHIP_MOVEMENT__H
#define SCRIPT_ENEMY_SHIP_MOVEMENT__H

// Script script_enemy_ship_movement_

#include "gbs_types.h"

BANKREF_EXTERN(script_enemy_ship_movement_)
extern const unsigned char script_enemy_ship_movement_[];

#endif
