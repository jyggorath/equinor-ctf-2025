#ifndef SCENE_SAMPLE_TOWN_SPRITES_H
#define SCENE_SAMPLE_TOWN_SPRITES_H

// Scene: town/Lykkeland
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_sample_town_sprites)
extern const far_ptr_t scene_sample_town_sprites[];

#endif
