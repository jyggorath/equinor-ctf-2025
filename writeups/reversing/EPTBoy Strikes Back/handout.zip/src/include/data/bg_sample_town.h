#ifndef BG_SAMPLE_TOWN_H
#define BG_SAMPLE_TOWN_H

// Background: sample_town

#include "gbs_types.h"

BANKREF_EXTERN(bg_sample_town)
extern const struct background_t bg_sample_town;

#endif
