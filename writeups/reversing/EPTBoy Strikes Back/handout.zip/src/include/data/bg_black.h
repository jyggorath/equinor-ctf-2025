#ifndef BG_BLACK_H
#define BG_BLACK_H

// Background: black

#include "gbs_types.h"

BANKREF_EXTERN(bg_black)
extern const struct background_t bg_black;

#endif
