#ifndef SCENE_DEEPER_UNDERGROUND_INIT_H
#define SCENE_DEEPER_UNDERGROUND_INIT_H

// Script scene_deeper_underground_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_deeper_underground_init)
extern const unsigned char scene_deeper_underground_init[];

#endif
