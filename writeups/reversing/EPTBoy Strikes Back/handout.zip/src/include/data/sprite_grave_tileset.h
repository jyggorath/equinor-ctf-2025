#ifndef SPRITE_GRAVE_TILESET_H
#define SPRITE_GRAVE_TILESET_H

// Tileset: sprite_grave_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_grave_tileset)
extern const struct tileset_t sprite_grave_tileset;

#endif
