#ifndef SPRITE_PLAYER_SHIP_H
#define SPRITE_PLAYER_SHIP_H

// SpriteSheet: player_ship

#include "gbs_types.h"

BANKREF_EXTERN(sprite_player_ship)
extern const struct spritesheet_t sprite_player_ship;

#endif
