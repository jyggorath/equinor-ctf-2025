#ifndef TRIGGER_17_INTERACT_H
#define TRIGGER_17_INTERACT_H

// Script trigger_17_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_17_interact)
extern const unsigned char trigger_17_interact[];

#endif
