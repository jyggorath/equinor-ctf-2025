#ifndef SPRITE_HIDDEN_STAIRS_TILESET_H
#define SPRITE_HIDDEN_STAIRS_TILESET_H

// Tileset: sprite_hidden_stairs_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_hidden_stairs_tileset)
extern const struct tileset_t sprite_hidden_stairs_tileset;

#endif
