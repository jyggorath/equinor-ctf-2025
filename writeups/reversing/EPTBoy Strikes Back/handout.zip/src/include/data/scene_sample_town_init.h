#ifndef SCENE_SAMPLE_TOWN_INIT_H
#define SCENE_SAMPLE_TOWN_INIT_H

// Script scene_sample_town_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_sample_town_init)
extern const unsigned char scene_sample_town_init[];

#endif
