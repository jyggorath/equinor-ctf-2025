#ifndef SCENE_SAMPLE_TOWN_COLLISIONS_H
#define SCENE_SAMPLE_TOWN_COLLISIONS_H

// Scene: town/Lykkeland
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_sample_town_collisions)
extern const unsigned char scene_sample_town_collisions[];

#endif
