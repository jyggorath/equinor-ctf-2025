#ifndef SCENE_SPACE_BATTLE_PROJECTILES_H
#define SCENE_SPACE_BATTLE_PROJECTILES_H

// Scene: space/Space Battle
// Projectiles

#include "gbs_types.h"

BANKREF_EXTERN(scene_space_battle_projectiles)
extern const far_ptr_t scene_space_battle_projectiles[];

#endif
