#ifndef SCENE_UNDERGROUND_INIT_H
#define SCENE_UNDERGROUND_INIT_H

// Script scene_underground_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_underground_init)
extern const unsigned char scene_underground_init[];

#endif
