#ifndef BG_SAMPLE_TOWN_CGB_TILESET_H
#define BG_SAMPLE_TOWN_CGB_TILESET_H

// Tileset: bg_sample_town_cgb_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_sample_town_cgb_tileset)
extern const struct tileset_t bg_sample_town_cgb_tileset;

#endif
