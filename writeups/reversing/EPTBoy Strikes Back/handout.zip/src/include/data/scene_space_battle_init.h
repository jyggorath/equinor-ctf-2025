#ifndef SCENE_SPACE_BATTLE_INIT_H
#define SCENE_SPACE_BATTLE_INIT_H

// Script scene_space_battle_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_space_battle_init)
extern const unsigned char scene_space_battle_init[];

#endif
