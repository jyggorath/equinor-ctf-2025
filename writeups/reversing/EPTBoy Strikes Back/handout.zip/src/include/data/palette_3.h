#ifndef PALETTE_3_H
#define PALETTE_3_H

// Palette: 3

#include "gbs_types.h"

BANKREF_EXTERN(palette_3)
extern const struct palette_t palette_3;

#endif
