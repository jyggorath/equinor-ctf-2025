#ifndef SCENE_UNDERGROUND_SPRITES_H
#define SCENE_UNDERGROUND_SPRITES_H

// Scene: caves/Underground
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_underground_sprites)
extern const far_ptr_t scene_underground_sprites[];

#endif
