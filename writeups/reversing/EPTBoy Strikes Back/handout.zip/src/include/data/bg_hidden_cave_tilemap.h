#ifndef BG_HIDDEN_CAVE_TILEMAP_H
#define BG_HIDDEN_CAVE_TILEMAP_H

// Tilemap bg_hidden_cave_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_hidden_cave_tilemap)
extern const unsigned char bg_hidden_cave_tilemap[];

#endif
