#ifndef ACTOR_ICE_BLOCK_INTERACT_H
#define ACTOR_ICE_BLOCK_INTERACT_H

// Script actor_ice_block_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_ice_block_interact)
extern const unsigned char actor_ice_block_interact[];

#endif
