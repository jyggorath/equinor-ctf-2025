#ifndef ACTOR_20_INTERACT_H
#define ACTOR_20_INTERACT_H

// Script actor_20_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_20_interact)
extern const unsigned char actor_20_interact[];

#endif
