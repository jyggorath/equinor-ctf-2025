#ifndef ACTOR_17_INTERACT_H
#define ACTOR_17_INTERACT_H

// Script actor_17_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_17_interact)
extern const unsigned char actor_17_interact[];

#endif
