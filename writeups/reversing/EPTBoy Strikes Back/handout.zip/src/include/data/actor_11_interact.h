#ifndef ACTOR_11_INTERACT_H
#define ACTOR_11_INTERACT_H

// Script actor_11_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_11_interact)
extern const unsigned char actor_11_interact[];

#endif
