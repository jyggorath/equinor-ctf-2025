#ifndef SPRITE_BULLET_LEFT_TILESET_H
#define SPRITE_BULLET_LEFT_TILESET_H

// Tileset: sprite_bullet_left_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_bullet_left_tileset)
extern const struct tileset_t sprite_bullet_left_tileset;

#endif
