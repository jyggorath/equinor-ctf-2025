#ifndef SCENE_19_H
#define SCENE_19_H

// Scene: Win

#include "gbs_types.h"

BANKREF_EXTERN(scene_19)
extern const struct scene_t scene_19;

#endif
