#ifndef ACTOR_7_INTERACT_H
#define ACTOR_7_INTERACT_H

// Script actor_7_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_7_interact)
extern const unsigned char actor_7_interact[];

#endif
