#ifndef SCRIPT_ENEMY_SHIP_HIT_PLAYE_H
#define SCRIPT_ENEMY_SHIP_HIT_PLAYE_H

// Script script_enemy_ship_hit_playe

#include "gbs_types.h"

BANKREF_EXTERN(script_enemy_ship_hit_playe)
extern const unsigned char script_enemy_ship_hit_playe[];

#endif
