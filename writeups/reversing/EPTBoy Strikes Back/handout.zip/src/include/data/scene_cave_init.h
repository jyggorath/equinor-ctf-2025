#ifndef SCENE_CAVE_INIT_H
#define SCENE_CAVE_INIT_H

// Script scene_cave_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_cave_init)
extern const unsigned char scene_cave_init[];

#endif
