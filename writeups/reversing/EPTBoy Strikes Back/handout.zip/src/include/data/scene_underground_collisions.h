#ifndef SCENE_UNDERGROUND_COLLISIONS_H
#define SCENE_UNDERGROUND_COLLISIONS_H

// Scene: caves/Underground
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_underground_collisions)
extern const unsigned char scene_underground_collisions[];

#endif
