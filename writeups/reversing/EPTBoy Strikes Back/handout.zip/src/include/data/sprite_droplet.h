#ifndef SPRITE_DROPLET_H
#define SPRITE_DROPLET_H

// SpriteSheet: droplet

#include "gbs_types.h"

BANKREF_EXTERN(sprite_droplet)
extern const struct spritesheet_t sprite_droplet;

#endif
