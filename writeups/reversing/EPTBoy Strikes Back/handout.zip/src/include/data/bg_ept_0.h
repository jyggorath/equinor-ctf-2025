#ifndef BG_EPT_0_H
#define BG_EPT_0_H

// Background: ept

#include "gbs_types.h"

BANKREF_EXTERN(bg_ept_0)
extern const struct background_t bg_ept_0;

#endif
