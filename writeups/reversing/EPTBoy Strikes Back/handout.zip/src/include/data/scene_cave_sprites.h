#ifndef SCENE_CAVE_SPRITES_H
#define SCENE_CAVE_SPRITES_H

// Scene: caves/Cave
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_cave_sprites)
extern const far_ptr_t scene_cave_sprites[];

#endif
