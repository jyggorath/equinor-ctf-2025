#ifndef SCENE_CAVE_TRIGGERS_H
#define SCENE_CAVE_TRIGGERS_H

// Scene: caves/Cave
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_cave_triggers)
extern const struct trigger_t scene_cave_triggers[];

#endif
