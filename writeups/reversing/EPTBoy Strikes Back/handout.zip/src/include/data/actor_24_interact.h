#ifndef ACTOR_24_INTERACT_H
#define ACTOR_24_INTERACT_H

// Script actor_24_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_24_interact)
extern const unsigned char actor_24_interact[];

#endif
