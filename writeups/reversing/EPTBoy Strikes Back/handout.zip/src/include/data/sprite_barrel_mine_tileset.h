#ifndef SPRITE_BARREL_MINE_TILESET_H
#define SPRITE_BARREL_MINE_TILESET_H

// Tileset: sprite_barrel_mine_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_barrel_mine_tileset)
extern const struct tileset_t sprite_barrel_mine_tileset;

#endif
