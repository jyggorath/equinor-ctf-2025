#ifndef ACTOR_SIGN_POST_3_INTERACT_H
#define ACTOR_SIGN_POST_3_INTERACT_H

// Script actor_sign_post_3_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_sign_post_3_interact)
extern const unsigned char actor_sign_post_3_interact[];

#endif
