#ifndef SPRITE_SAGE_BANK2_TILESET_H
#define SPRITE_SAGE_BANK2_TILESET_H

// Tileset: sprite_sage_bank2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_sage_bank2_tileset)
extern const struct tileset_t sprite_sage_bank2_tileset;

#endif
