#ifndef ACTOR_36_INTERACT_H
#define ACTOR_36_INTERACT_H

// Script actor_36_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_36_interact)
extern const unsigned char actor_36_interact[];

#endif
