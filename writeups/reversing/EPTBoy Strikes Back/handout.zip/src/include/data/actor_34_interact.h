#ifndef ACTOR_34_INTERACT_H
#define ACTOR_34_INTERACT_H

// Script actor_34_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_34_interact)
extern const unsigned char actor_34_interact[];

#endif
