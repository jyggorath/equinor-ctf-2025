#ifndef SCENE_LOGO_INIT_H
#define SCENE_LOGO_INIT_H

// Script scene_logo_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_logo_init)
extern const unsigned char scene_logo_init[];

#endif
