#ifndef PALETTE_5_H
#define PALETTE_5_H

// Palette: 5

#include "gbs_types.h"

BANKREF_EXTERN(palette_5)
extern const struct palette_t palette_5;

#endif
