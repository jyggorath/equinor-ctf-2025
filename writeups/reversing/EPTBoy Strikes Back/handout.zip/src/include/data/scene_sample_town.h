#ifndef SCENE_SAMPLE_TOWN_H
#define SCENE_SAMPLE_TOWN_H

// Scene: town/Lykkeland

#include "gbs_types.h"

BANKREF_EXTERN(scene_sample_town)
extern const struct scene_t scene_sample_town;

#endif
