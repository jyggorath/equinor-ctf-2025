#ifndef BG_EPT_0_TILEMAP_H
#define BG_EPT_0_TILEMAP_H

// Tilemap bg_ept_0_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_ept_0_tilemap)
extern const unsigned char bg_ept_0_tilemap[];

#endif
