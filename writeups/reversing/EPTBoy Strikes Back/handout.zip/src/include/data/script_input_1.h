#ifndef SCRIPT_INPUT_1_H
#define SCRIPT_INPUT_1_H

// Script script_input_1

#include "gbs_types.h"

BANKREF_EXTERN(script_input_1)
extern const unsigned char script_input_1[];

#endif
