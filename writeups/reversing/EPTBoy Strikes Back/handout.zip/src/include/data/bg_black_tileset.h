#ifndef BG_BLACK_TILESET_H
#define BG_BLACK_TILESET_H

// Tileset: bg_black_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_black_tileset)
extern const struct tileset_t bg_black_tileset;

#endif
