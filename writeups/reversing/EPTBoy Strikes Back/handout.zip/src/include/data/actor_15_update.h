#ifndef ACTOR_15_UPDATE_H
#define ACTOR_15_UPDATE_H

// Script actor_15_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_15_update)
extern const unsigned char actor_15_update[];

#endif
