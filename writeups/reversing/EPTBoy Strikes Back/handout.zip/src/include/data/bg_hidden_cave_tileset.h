#ifndef BG_HIDDEN_CAVE_TILESET_H
#define BG_HIDDEN_CAVE_TILESET_H

// Tileset: bg_hidden_cave_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_hidden_cave_tileset)
extern const struct tileset_t bg_hidden_cave_tileset;

#endif
