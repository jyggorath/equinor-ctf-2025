#ifndef MUSIC_DATA_H
#define MUSIC_DATA_H

extern const void __bank_song_rulz_fastpacespeedrace_0_Data;
extern const void song_rulz_fastpacespeedrace_0_Data;
extern const void __bank_song_rulz_intro_0_Data;
extern const void song_rulz_intro_0_Data;
extern const void __bank_song_rulz_lightmood_0_Data;
extern const void song_rulz_lightmood_0_Data;
extern const void __bank_song_rulz_outside_0_Data;
extern const void song_rulz_outside_0_Data;
extern const void __bank_song_rulz_pause_underground_0_Data;
extern const void song_rulz_pause_underground_0_Data;
extern const void __bank_song_rulz_undergroundcave_0_Data;
extern const void song_rulz_undergroundcave_0_Data;

#endif
