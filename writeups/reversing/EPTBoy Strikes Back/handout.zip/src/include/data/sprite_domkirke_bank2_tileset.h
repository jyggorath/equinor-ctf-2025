#ifndef SPRITE_DOMKIRKE_BANK2_TILESET_H
#define SPRITE_DOMKIRKE_BANK2_TILESET_H

// Tileset: sprite_domkirke_bank2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_domkirke_bank2_tileset)
extern const struct tileset_t sprite_domkirke_bank2_tileset;

#endif
