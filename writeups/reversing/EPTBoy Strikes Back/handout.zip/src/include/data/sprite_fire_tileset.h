#ifndef SPRITE_FIRE_TILESET_H
#define SPRITE_FIRE_TILESET_H

// Tileset: sprite_fire_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_fire_tileset)
extern const struct tileset_t sprite_fire_tileset;

#endif
