#ifndef ACTOR_28_UPDATE_H
#define ACTOR_28_UPDATE_H

// Script actor_28_update

#include "gbs_types.h"

BANKREF_EXTERN(actor_28_update)
extern const unsigned char actor_28_update[];

#endif
