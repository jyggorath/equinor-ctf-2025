#ifndef BG_BACKGROUND_WIDE_TILESET_H
#define BG_BACKGROUND_WIDE_TILESET_H

// Tileset: bg_background_wide_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_background_wide_tileset)
extern const struct tileset_t bg_background_wide_tileset;

#endif
