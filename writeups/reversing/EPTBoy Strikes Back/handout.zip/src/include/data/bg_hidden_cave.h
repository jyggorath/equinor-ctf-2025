#ifndef BG_HIDDEN_CAVE_H
#define BG_HIDDEN_CAVE_H

// Background: hidden_cave

#include "gbs_types.h"

BANKREF_EXTERN(bg_hidden_cave)
extern const struct background_t bg_hidden_cave;

#endif
