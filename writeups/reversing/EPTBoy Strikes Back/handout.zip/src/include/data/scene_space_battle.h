#ifndef SCENE_SPACE_BATTLE_H
#define SCENE_SPACE_BATTLE_H

// Scene: space/Space Battle

#include "gbs_types.h"

BANKREF_EXTERN(scene_space_battle)
extern const struct scene_t scene_space_battle;

#endif
