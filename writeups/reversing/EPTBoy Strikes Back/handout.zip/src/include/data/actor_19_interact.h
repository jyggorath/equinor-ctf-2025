#ifndef ACTOR_19_INTERACT_H
#define ACTOR_19_INTERACT_H

// Script actor_19_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_19_interact)
extern const unsigned char actor_19_interact[];

#endif
