#ifndef SCENE_DEEPER_UNDERGROUND_TRIGGERS_H
#define SCENE_DEEPER_UNDERGROUND_TRIGGERS_H

// Scene: caves/Deeper Underground
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_deeper_underground_triggers)
extern const struct trigger_t scene_deeper_underground_triggers[];

#endif
