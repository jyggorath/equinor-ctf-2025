#ifndef BG_EPT_TILEMAP_H
#define BG_EPT_TILEMAP_H

// Tilemap bg_ept_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_ept_tilemap)
extern const unsigned char bg_ept_tilemap[];

#endif
