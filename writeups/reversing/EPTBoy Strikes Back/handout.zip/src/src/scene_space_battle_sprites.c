#pragma bank 255

// Scene: space/Space Battle
// Sprites

#include "gbs_types.h"
#include "data/sprite_enemy_ship.h"
#include "data/sprite_barrel_mine.h"
#include "data/sprite_droplet.h"
#include "data/sprite_bullet_left.h"

BANKREF(scene_space_battle_sprites)

const far_ptr_t scene_space_battle_sprites[] = {
    TO_FAR_PTR_T(sprite_enemy_ship),
    TO_FAR_PTR_T(sprite_barrel_mine),
    TO_FAR_PTR_T(sprite_droplet),
    TO_FAR_PTR_T(sprite_bullet_left)
};
