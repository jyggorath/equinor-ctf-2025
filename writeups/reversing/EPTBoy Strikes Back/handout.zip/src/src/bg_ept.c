#pragma bank 255

// Background: gameboy

#include "gbs_types.h"
#include "data/bg_ept_tileset.h"
#include "data/bg_ept_cgb_tileset.h"
#include "data/bg_ept_tilemap.h"
#include "data/bg_ept_tilemap_attr.h"

BANKREF(bg_ept)

const struct background_t bg_ept = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_ept_tileset),
    .cgb_tileset = TO_FAR_PTR_T(bg_ept_cgb_tileset),
    .tilemap = TO_FAR_PTR_T(bg_ept_tilemap),
    .cgb_tilemap_attr = TO_FAR_PTR_T(bg_ept_tilemap_attr)
};
