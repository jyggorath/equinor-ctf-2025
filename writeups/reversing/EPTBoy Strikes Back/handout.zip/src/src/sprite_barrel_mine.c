#pragma bank 255
// SpriteSheet: barrel_mine

#include "gbs_types.h"
#include "data/sprite_barrel_mine_tileset.h"
#include "data/sprite_barrel_mine_bank2_tileset.h"

BANKREF(sprite_barrel_mine)

#define SPRITE_14_STATE_DEFAULT 0
#define SPRITE_14_STATE_EXPLODE 8
#define SPRITE_14_STATE_OPEN 0

const metasprite_t sprite_barrel_mine_metasprite_0[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_barrel_mine_metasprite_1[]  = {
    { 0, 8, 4, 0 }, { 0, -8, 6, 0 },
    {metasprite_end}
};

const metasprite_t sprite_barrel_mine_metasprite_2[]  = {
    { 0, 8, 8, 0 }, { 0, -8, 10, 0 },
    {metasprite_end}
};

const metasprite_t sprite_barrel_mine_metasprite_3[]  = {
    { 0, 8, 0, 8 }, { 0, -8, 2, 8 },
    {metasprite_end}
};

const metasprite_t sprite_barrel_mine_metasprite_4[]  = {
    { 0, 8, 4, 8 }, { 0, -8, 6, 8 },
    {metasprite_end}
};

const metasprite_t sprite_barrel_mine_metasprite_5[]  = {
    { 0, 8, 8, 8 }, { 0, -8, 10, 8 },
    {metasprite_end}
};

const metasprite_t * const sprite_barrel_mine_metasprites[] = {
    sprite_barrel_mine_metasprite_0,
    sprite_barrel_mine_metasprite_1,
    sprite_barrel_mine_metasprite_2,
    sprite_barrel_mine_metasprite_3,
    sprite_barrel_mine_metasprite_4,
    sprite_barrel_mine_metasprite_5
};

const struct animation_t sprite_barrel_mine_animations[] = {
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 0,
        .end = 1
    },
    {
        .start = 2,
        .end = 5
    },
    {
        .start = 2,
        .end = 5
    },
    {
        .start = 2,
        .end = 5
    },
    {
        .start = 2,
        .end = 5
    },
    {
        .start = 2,
        .end = 5
    },
    {
        .start = 2,
        .end = 5
    },
    {
        .start = 2,
        .end = 5
    },
    {
        .start = 2,
        .end = 5
    }
};

const UWORD sprite_barrel_mine_animations_lookup[] = {
    SPRITE_14_STATE_DEFAULT,
    SPRITE_14_STATE_EXPLODE
};

const struct spritesheet_t sprite_barrel_mine = {
    .n_metasprites = 6,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_barrel_mine_metasprites,
    .animations = sprite_barrel_mine_animations,
    .animations_lookup = sprite_barrel_mine_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_barrel_mine_tileset),
    .cgb_tileset = TO_FAR_PTR_T(sprite_barrel_mine_bank2_tileset)
};
