#pragma bank 255

// Scene: town/Lykkeland
// Triggers

#include "gbs_types.h"
#include "data/trigger_2_interact.h"
#include "data/trigger_3_interact.h"

BANKREF(scene_sample_town_triggers)

const struct trigger_t scene_sample_town_triggers[] = {
    {
        // Trigger 1,
        .x = 2,
        .y = 55,
        .width = 4,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_2_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 0,
        .y = 9,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_3_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
