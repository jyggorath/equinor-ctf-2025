#pragma bank 255
// SpriteSheet: flappy

#include "gbs_types.h"
#include "data/sprite_flappy_tileset.h"
#include "data/sprite_flappy_bank2_tileset.h"

BANKREF(sprite_flappy)

#define SPRITE_17_STATE_DEFAULT 0
#define SPRITE_17_STATE_EXPLODE 0
#define SPRITE_17_STATE_OPEN 0

const metasprite_t sprite_flappy_metasprite_0[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 8 },
    {metasprite_end}
};

const metasprite_t sprite_flappy_metasprite_1[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_flappy_metasprite_2[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 0, 8 },
    {metasprite_end}
};

const metasprite_t sprite_flappy_metasprite_3[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 2, 32 },
    {metasprite_end}
};

const metasprite_t sprite_flappy_metasprite_4[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 2, 40 },
    {metasprite_end}
};

const metasprite_t sprite_flappy_metasprite_5[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 0, 40 },
    {metasprite_end}
};

const metasprite_t * const sprite_flappy_metasprites[] = {
    sprite_flappy_metasprite_0,
    sprite_flappy_metasprite_1,
    sprite_flappy_metasprite_2,
    sprite_flappy_metasprite_3,
    sprite_flappy_metasprite_0,
    sprite_flappy_metasprite_2,
    sprite_flappy_metasprite_1,
    sprite_flappy_metasprite_4,
    sprite_flappy_metasprite_5,
    sprite_flappy_metasprite_3
};

const struct animation_t sprite_flappy_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 3,
        .end = 3
    },
    {
        .start = 4,
        .end = 6
    },
    {
        .start = 4,
        .end = 6
    },
    {
        .start = 4,
        .end = 6
    },
    {
        .start = 7,
        .end = 9
    }
};

const UWORD sprite_flappy_animations_lookup[] = {
    SPRITE_17_STATE_DEFAULT
};

const struct spritesheet_t sprite_flappy = {
    .n_metasprites = 10,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_flappy_metasprites,
    .animations = sprite_flappy_animations,
    .animations_lookup = sprite_flappy_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_flappy_tileset),
    .cgb_tileset = TO_FAR_PTR_T(sprite_flappy_bank2_tileset)
};
