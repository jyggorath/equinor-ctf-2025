#pragma bank 255

// Scene: town/Lykkeland
// Sprites

#include "gbs_types.h"
#include "data/sprite_signpost.h"
#include "data/sprite_barrel_mine.h"
#include "data/sprite_flappy.h"
#include "data/sprite_chest.h"
#include "data/sprite_office.h"
#include "data/sprite_domkirke.h"
#include "data/sprite_grave.h"

BANKREF(scene_sample_town_sprites)

const far_ptr_t scene_sample_town_sprites[] = {
    TO_FAR_PTR_T(sprite_signpost),
    TO_FAR_PTR_T(sprite_barrel_mine),
    TO_FAR_PTR_T(sprite_flappy),
    TO_FAR_PTR_T(sprite_chest),
    TO_FAR_PTR_T(sprite_office),
    TO_FAR_PTR_T(sprite_domkirke),
    TO_FAR_PTR_T(sprite_grave)
};
