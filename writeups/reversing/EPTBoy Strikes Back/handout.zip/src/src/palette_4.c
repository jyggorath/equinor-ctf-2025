#pragma bank 255

// Palette: 4

#include "gbs_types.h"

BANKREF(palette_4)

const struct palette_t palette_4 = {
    .mask = 0xFF,
    .palette = {
        DMG_PALETTE(DMG_WHITE, DMG_LITE_GRAY, DMG_DARK_GRAY, DMG_BLACK)
    },
    .cgb_palette = {
        CGB_PALETTE(RGB(17, 17, 17), RGB(31, 6, 1), RGB(4, 0, 1), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(17, 17, 17), RGB(4, 0, 1), RGB(4, 0, 1), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(31, 6, 1), RGB(31, 5, 1), RGB(1, 0, 1), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(31, 6, 1), RGB(31, 3, 1), RGB(3, 0, 1), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(31, 6, 1), RGB(31, 5, 1), RGB(1, 0, 1), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(0, 31, 3), RGB(31, 6, 1), RGB(4, 0, 1), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(17, 17, 17), RGB(31, 6, 1), RGB(31, 3, 1), RGB(0, 0, 1)),
        CGB_PALETTE(RGB(31, 31, 23), RGB(18, 25, 25), RGB(9, 13, 15), RGB(1, 4, 9))
    }
};
