docker build . -t eptboy-builder
docker run -it -v ./src:/workdir eptboy-builder
echo "Now you can load ./src/build/rom.gb in your favorite GameBoy emulator"
